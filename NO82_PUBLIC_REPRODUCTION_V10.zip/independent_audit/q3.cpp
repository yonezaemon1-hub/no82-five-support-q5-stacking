// Independent exact Q3 endpoint-profile DP + glue tests for Q4 splits
#include <bits/stdc++.h>
using namespace std; typedef long long ll; typedef unsigned long long ull;
const int T=22; // max stones considered per half-cube
ll Ncomp[10][T+2]; // Ncomp[k][s]: compositions of s into k nonneg parts
ll rankCfg(const int*c){int rem=T;ll r=0;for(int i=0;i<8;i++){for(int x=0;x<c[i];x++)r+=Ncomp[9-i-1][rem-x];rem-=c[i];}return r;}
// parts after i: remaining parts count = 9-i-1 (including slack)
vector<array<uint8_t,8>> F;
int main(){
  for(int k=0;k<10;k++)for(int s=0;s<=T+1;s++){ if(k==0)Ncomp[k][s]=(s==0); else if(s==0)Ncomp[k][s]=1; else Ncomp[k][s]=Ncomp[k-1][s]+Ncomp[k][s-1]; }
  ll NS=Ncomp[9][T]; fprintf(stderr,"states=%lld\n",NS);
  F.assign(NS,array<uint8_t,8>{});
  // enumerate by total t ascending
  vector<array<int8_t,8>> lvl;
  int c[8];
  for(int t=1;t<=T;t++){
    // enumerate all compositions of t into 8 parts
    function<void(int,int)> rec=[&](int i,int rem){
      if(i==7){c[7]=rem; ll r=rankCfg(c); array<uint8_t,8> f{};
        int sup=0,su=-1;for(int j=0;j<8;j++)if(c[j]){sup++;su=j;}
        if(sup==1)f[su]=t;
        for(int u=0;u<8;u++)if(c[u]>=2)for(int b=0;b<3;b++){int v=u^(1<<b);c[u]-=2;c[v]++;ll r2=rankCfg(c);c[u]+=2;c[v]--;
          for(int w=0;w<8;w++)f[w]=max(f[w],F[r2][w]);}
        F[r]=f;return;}
      for(int x=0;x<=rem;x++){c[i]=x;rec(i+1,rem-x);} };
    rec(0,t);
  }
  // path DP: stackable[d][p][q] with endpoints on path of d+1 vertices
  // exact memo
  map<pair<int,ull>,bool> memo;
  function<bool(int,array<int,6>&)> st;
  // use encoded state
  unordered_map<ull,char> pm[5];
  function<bool(int,int*)> pstack=[&](int n,int*a)->bool{ // n vertices
    ull key=0;int sup=0;for(int i=0;i<n;i++){key=key*32+a[i];if(a[i])sup++;}
    if(sup<=1)return true;
    auto it=pm[n-1].find(key);if(it!=pm[n-1].end())return it->second;
    bool res=false;
    for(int i=0;i<n&&!res;i++)if(a[i]>=2)for(int dlt=-1;dlt<=1&&!res;dlt+=2){int j=i+dlt;if(j<0||j>=n)continue;a[i]-=2;a[j]++;res=pstack(n,a);a[i]+=2;a[j]--;}
    pm[n-1][key]=res;return res;};
  static char PS[5][32][32];
  for(int d=1;d<=4;d++)for(int p=0;p<=22;p++)for(int q=0;q<=22;q++){ if(p+q>31){PS[d][p][q]=0;continue;} int a[6]={0};a[0]=p;a[d]=q;PS[d][p][q]=pstack(d+1,a);} 
  fprintf(stderr,"path dp done\n");
  // Q3 facts
  // number of unstackable per t
  vector<vector<ll>> unst(T+1);
  map<int,ll> cnt_unst,cnt_all;
  // profile classes per t: map profile->count (stackable only), and unstackable list
  vector<map<ull,ll>> prof(T+1);
  vector<ll> allc(T+1,0),unc(T+1,0);
  for(int t=1;t<=T;t++){
    function<void(int,int)> rec=[&](int i,int rem){
      if(i==7){c[7]=rem; ll r=rankCfg(c); ull key=0;bool any=false;for(int j=0;j<8;j++){key=key*32+F[r][j];if(F[r][j])any=true;}
        allc[t]++; if(any)prof[t][key]++; else unc[t]++; return;}
      for(int x=0;x<=rem;x++){c[i]=x;rec(i+1,rem-x);} };
    rec(0,t);
  }
  for(int t=1;t<=T;t++)printf("t=%d configs=%lld unstackable=%lld profile_classes=%zu\n",t,allc[t],unc[t],prof[t].size());
  auto dec=[&](ull key,int*f){for(int j=7;j>=0;j--){f[j]=key%32;key/=32;}};
  // glue test: A in layer0, B in layer1 ; sizes a,b
  auto glue=[&](int a,int b){
    vector<array<int,8>> PA,PB;
    for(auto&kv:prof[a]){array<int,8> f;dec(kv.first,f.data());PA.push_back(f);}
    for(auto&kv:prof[b]){array<int,8> f;dec(kv.first,f.data());PB.push_back(f);}
    ll bad=0;ll badcfg=0;
    vector<pair<ull,ull>> badpairs;
    for(size_t i=0;i<PA.size();i++)for(size_t j=0;j<PB.size();j++){
      bool ok=false;
      for(int u=0;u<8&&!ok;u++){int p=PA[i][u];if(!p)continue;for(int v=0;v<8;v++){int q=PB[j][v];if(!q)continue;int d=1+__builtin_popcount(u^v);if(PS[d][p][q]){ok=true;break;}}}
      if(!ok)bad++;
    }
    printf("glue(%d,%d): classes %zu x %zu = %zu ; unglued class pairs (both stackable) = %lld\n",a,b,PA.size(),PB.size(),PA.size()*PB.size(),bad);fflush(stdout);
  };
  int pairs[][2]={{15,16},{15,15},{14,16},{13,17},{12,19},{11,20},{10,21},{9,22},{10,20},{10,18},{11,19},{11,17},{12,18},{13,18},{14,17},{16,14}};
  for(auto&pr:pairs)glue(pr[0],pr[1]);
  // bad-donor classification for minority t=9..12: unstackable c; S(c)={w: c+e_w unstackable}
  for(int t=9;t<=14;t++){
    map<int,ll> byS;ll n=0; map<string,ll> forms;
    function<void(int,int)> rec=[&](int i,int rem){
      if(i==7){c[7]=rem; ll r=rankCfg(c);bool any=false;for(int j=0;j<8;j++)if(F[r][j])any=true; if(any)return; n++;
        int S=0;for(int w=0;w<8;w++){c[w]++;ll r2=rankCfg(c);c[w]--;bool a2=false;for(int j=0;j<8;j++)if(F[r2][j])a2=true;if(!a2)S|=1<<w;}
        // classify S
        string s; int pc=__builtin_popcount(S); if(pc==0)s="empty"; else if(pc==1)s="single"; else if(pc==4){bool par=true;int p0=__builtin_popcount(__builtin_ctz(S))&1;for(int w=0;w<8;w++)if(S>>w&1)if((__builtin_popcount(w)&1)!=p0)par=false; s=par?"parity4":"other4";} else s="other"+to_string(pc);
        forms[s]++; return;}
      for(int x=0;x<=rem;x++){c[i]=x;rec(i+1,rem-x);} };
    rec(0,t);
    printf("minority t=%d unstackable=%lld :",t,n);for(auto&kv:forms)printf(" %s=%lld",kv.first.c_str(),kv.second);printf("\n");
  }
  // 14-stone unstackable are exactly 13e_u+e_{u^7}?
  { ll n=0,okform=0; function<void(int,int)> rec=[&](int i,int rem){ if(i==7){c[7]=rem;ll r=rankCfg(c);bool any=false;for(int j=0;j<8;j++)if(F[r][j])any=true;if(any)return;n++;
        for(int u=0;u<8;u++)if(c[u]==13&&c[u^7]==1)okform++;return;}
      for(int x=0;x<=rem;x++){c[i]=x;rec(i+1,rem-x);} };
    rec(0,14);printf("t=14 unstackable=%lld of form 13e_u+e_{u^7}: %lld\n",n,okform);}
}
