import itertools, math, json
from collections import Counter
N=32
# group: perm of 5 coords x xor mask
perms=list(itertools.permutations(range(5)))
def pmap(p):
    t=[0]*32
    for x in range(32):
        y=0
        for i in range(5):
            if (x>>i)&1: y|=1<<p[i]
        t[x]=y
    return t
PM=[pmap(p) for p in perms]
G=[(pm,m) for pm in PM for m in range(32)]
assert len(G)==3840
supports=list(itertools.combinations(range(32),5))
assert len(supports)==math.comb(32,5)==201376
def cls(S):
    sp=[]
    for b in range(5):
        c=sum((x>>b)&1 for x in S); sp.append(min(c,5-c))
    return sp
const=single=bal=0
balset=[]
for S in supports:
    sp=cls(S)
    if 0 in sp: const+=1
    elif 1 in sp: single+=1
    else: bal+=1; balset.append(S)
print("const",const,"single",single,"bal",bal)
# orbits
seen=set(); orbits=[]
for S in balset:
    if S in seen: continue
    orb={tuple(sorted(pm[x]^m for x in S)) for pm,m in G}
    assert not (orb&seen)
    assert all(cls(T).count(2)==5 for T in orb)
    seen|=orb; orbits.append((min(orb),len(orb)))
print(len(orbits),sorted([o[1] for o in orbits],reverse=True), sum(o[1] for o in orbits))
assert seen==set(balset)
json.dump([[list(r),n] for r,n in orbits],open('orbits.json','w'))
print(math.comb(32,5)*math.comb(62,4), 24064*math.comb(62,4), 177312*math.comb(62,4))
print(math.comb(46,15), 16*41677241)
