import sys
sys.setrecursionlimit(100000)
exec(open('replay.py').read().split("# ---- v1.4")[0])
# recompute c10 rows
def has_c10(S):
    S=set(S);start=min(S)
    def dfs(path,vis):
        if len(path)==10: return path if (bin(path[-1]^start).count('1')==1 and S<=vis) else None
        for k in range(5):
            w=path[-1]^(1<<k)
            if w in vis: continue
            r=dfs(path+[w],vis|{w})
            if r: return r
        return None
    return dfs([start],{start})
import csv
seen=set()
for row in csv.reader(open(V14+'data/all_certificates.csv')):
    if row[0]=='orbit_index0': continue
    seen.add(tuple(int(x) for x in row[:6]))
left=resid-seen
rows=[r for r in left if sorted(r[1:])==[1,1,1,1,59] and has_c10(REPS[r[0]])]
print(len(rows))
import itertools
def solve_cycle(cyc,counts):
    n=10; a=tuple(counts)
    from functools import lru_cache
    seenstates=set(); path=[]
    # DFS with memo of failed states, prefer moves that increase potential toward pile
    def rec(st):
        if sum(1 for x in st if x)<=1: return True
        if st in seenstates: return False
        seenstates.add(st)
        if len(seenstates)>6_000_000: raise TimeoutError
        cand=[]
        for i in range(n):
            if st[i]>=2:
                for j in ((i-1)%n,(i+1)%n):
                    b=list(st);b[i]-=2;b[j]+=1;b=tuple(b)
                    # heuristic: maximize sum of squares (concentration)
                    cand.append((-sum(x*x for x in b),i,j,b))
        cand.sort()
        for _,i,j,b in cand:
            path.append((i,j))
            if rec(b): return True
            path.pop()
        return False
    ok=rec(a)
    return ok,list(path),len(seenstates)
for r in rows:
    S=REPS[r[0]];cyc=has_c10(S)
    counts=[0]*10
    for x,c in zip(S,r[1:]): counts[cyc.index(x)]=c
    try:
        ok,p,n=solve_cycle(cyc,counts)
    except TimeoutError:
        ok,p,n=None,[],-1
    print(r,cyc,counts,ok,len(p),n)
    if ok:
        # replay in Q5
        a=[0]*32
        for x,c in zip(S,r[1:]): a[x]=c
        for i,j in p:
            assert legal(a,cyc[i],cyc[j])
        assert sum(1 for x in a if x)==1
        print("  replay ok, moves",len(p))
