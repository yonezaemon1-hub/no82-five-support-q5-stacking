import itertools
V14='/tmp/claude-0/aud/ex/NO82_Q5_FIVE_SUPPORT_V14_PRIVATE_HOLD/NO82_Q5_FIVE_SUPPORT_V14_PRIVATE_HOLD/'
theirs_reps=[(0,1,6,26,29),(0,1,6,26,31),(0,1,6,27,30),(0,1,6,27,31),(0,1,14,22,27),(0,3,12,21,27),(0,3,12,21,31),(0,1,6,25,30),(0,1,6,27,29),(0,1,14,22,31),(0,3,5,24,30),(0,3,5,24,31),(0,3,5,26,28),(0,3,12,21,26),(0,3,13,21,26),(0,1,2,29,31),(0,1,6,24,31),(0,1,6,30,31),(0,3,12,23,29),(0,1,2,28,31),(0,1,2,29,30),(0,3,5,25,30)]
my_reps=[(0,1,2,28,31),(0,1,2,29,30),(0,1,2,29,31),(0,1,6,24,31),(0,1,6,25,30),(0,1,6,26,29),(0,1,6,26,31),(0,1,6,27,29),(0,1,6,27,30),(0,1,6,27,31),(0,1,6,30,31),(0,1,14,22,27),(0,1,14,22,31),(0,3,5,24,30),(0,3,5,24,31),(0,3,5,25,30),(0,3,5,26,28),(0,3,12,21,26),(0,3,12,21,27),(0,3,12,21,31),(0,3,12,23,29),(0,3,13,21,26)]
def pm(p,x):
    y=0
    for i in range(5):
        if (x>>i)&1: y|=1<<p[i]
    return y
def find(S,T):
    for p in itertools.permutations(range(5)):
        for m in range(32):
            if tuple(sorted(pm(p,x)^m for x in S))==T: return p,m
    raise Exception
mp={}
for s,S in enumerate(my_reps):
    T=[t for t in range(22) if True]
    for t,Tt in enumerate(theirs_reps):
        try:
            g=find(S,Tt); mp[s]=(t,g); break
        except Exception: pass
assert len(mp)==22 and len({v[0] for v in mp.values()})==22
d=open('my_residual.bin','rb').read(); mine=set()
for i in range(0,len(d),6):
    r=d[i:i+6]; s=r[0]; t,(p,m)=mp[s]
    img={pm(p,x)^m:c for x,c in zip(my_reps[s],r[1:])}
    mine.add((t,)+tuple(img[x] for x in theirs_reps[t]))
th=open(V14+'data/residual_2.bin','rb').read()
theirs={tuple(th[i:i+6]) for i in range(0,len(th),6)}
print(len(d)//6,len(mine),len(theirs),mine==theirs)
