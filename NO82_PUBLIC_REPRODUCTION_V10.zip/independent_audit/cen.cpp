// Independent re-implementation of Q4 "centered" class check (own path-cover generator, exact donor assignment)
#include <bits/stdc++.h>
using namespace std; typedef long long ll;
struct Opt{int I,p,z;};
vector<Opt> opts[256];
int pop(int x){return __builtin_popcount(x);}
// all simple paths in Q3 as (mask,start,end)
struct P{int mask,s,e;};
vector<P> paths;
void gen(int start,int cur,int mask){paths.push_back({mask,start,cur});for(int b=0;b<3;b++){int n=cur^(1<<b);if(!(mask>>n&1))gen(start,n,mask|1<<n);}}
set<tuple<int,int,int>> cur_set;
void cover(int R,int rem,int used,int I,int p,int z,set<tuple<int,int,int>>&out){
  if(!rem){out.insert({I,p,z});return;}
  int bit=rem&-rem;
  for(auto&pa:paths){
    if(!(pa.mask&bit))continue; if(pa.mask&used)continue;
    if(!(R>>pa.s&1)||!(R>>pa.e&1))continue;
    int part=pa.mask&R; if(part&~rem)continue;
    int zeros=pa.mask&~R;
    cover(R,rem&~part,used|pa.mask,I|(1<<pa.s)|zeros,p+1,z+pop(zeros),out);
  }
}
int dd[8][8];
int Aarr[8];int cap[8];
int unitsS[16],nu;
bool dfs(int i,int budget,int lastS,int lastU){
  if(i==nu)return true;
  int s=unitsS[i];
  int u0=(s==lastS)?lastU:0;
  for(int u=u0;u<8;u++){int w=1<<dd[u][s];if(cap[u]<w)continue;if(w-1>budget)continue;
    cap[u]-=w;bool ok=dfs(i+1,budget-(w-1),s,u);cap[u]+=w;if(ok)return true;}
  return false;
}
bool feasible(int I,const int*A,int budget){
  nu=0;
  for(int x=0;x<8;x++){ if(I>>x&1){ if(A[x]<2){int d=2-A[x];while(d--)unitsS[nu++]=x;} cap[x]=A[x]>=2?A[x]-2:0;} else cap[x]=A[x]; }
  if(!nu)return true;
  return dfs(0,budget,-1,0);
}
int c[16],coord[4];
ll total=0,ok0=0,ok1=0,failn=0;
vector<array<int,16>> fails;
int embed(int k,int s,int x){int v=0,j=0;for(int b=0;b<4;b++){if(b==k)v|=s<<b;else{v|=((x>>j)&1)<<b;j++;}}return v;}
bool solveCfg(){
  for(int k=0;k<4;k++){
    int A[8],R=0,q=0,r=0;
    for(int x=0;x<8;x++){int av=embed(k,0,x),bv=av^(1<<k);A[x]=c[av]+c[bv]/2;q+=c[bv]/2;if(c[bv]&1){R|=1<<x;r++;}}
    for(auto&o:opts[R]){int budget=31-q-r-o.p-2*o.z-15;if(budget<0)break;if(feasible(o.I,A,budget))return true;}
  }
  return false;
}
int part=0,nparts=1;
void inspect(int rem){c[0]=rem;total++;if(solveCfg())ok0++;else{failn++;array<int,16> a;for(int i=0;i<16;i++)a[i]=c[i];fails.push_back(a);}}
void rec(int v,int rem){
  if(v==16){inspect(rem);return;}
  int lim=rem;for(int k=0;k<4;k++)if(v>>k&1)lim=min(lim,8-coord[k]);
  for(int x=0;x<=lim;x++){
    if(v==1 && x%nparts!=part)continue;
    c[v]=x;for(int k=0;k<4;k++)if(v>>k&1)coord[k]+=x;rec(v+1,rem-x);for(int k=0;k<4;k++)if(v>>k&1)coord[k]-=x;}
}
int main(int argc,char**argv){
  if(argc>2){part=atoi(argv[1]);nparts=atoi(argv[2]);}
  for(int i=0;i<8;i++)for(int j=0;j<8;j++)dd[i][j]=pop(i^j);
  for(int s=0;s<8;s++)gen(s,s,1<<s);
  ll nopt=0;
  for(int R=0;R<256;R++){set<tuple<int,int,int>> out;cover(R,R,0,0,0,0,out);for(auto&t:out)opts[R].push_back({get<0>(t),get<1>(t),get<2>(t)});
    sort(opts[R].begin(),opts[R].end(),[](const Opt&a,const Opt&b){return a.p+2*a.z<b.p+2*b.z;});nopt+=opts[R].size();}
  fprintf(stderr,"options=%lld\n",nopt);
  rec(1,31);
  printf("part %d/%d total=%lld ok=%lld fail=%lld\n",part,nparts,total,ok0,failn);
  for(auto&a:fails){for(int i=0;i<16;i++)printf("%d%c",a[i],i<15?',':'\n');}
}
