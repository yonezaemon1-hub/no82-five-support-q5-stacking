import random, itertools
def pc(x): return bin(x).count('1')
def run(S_F0,u,v,a,b,axis=4):
    # S_F0: list of occupied vertices (5-bit) with bit4=0; u=v|16 ; a: counts ; b count at u
    arr=[0]*32
    for x,c in zip(S_F0,a):arr[x]=c
    arr[u]=b
    def mv(x,y):
        assert pc(x^y)==1 and arr[x]>=2; arr[x]-=2;arr[y]+=1
    def deliver(x):
        # move one pebble from x to v along shortest path, requires 2^d at x
        path=[x];cur=x
        for i in range(4):
            if (cur^v)>>i&1: cur^=1<<i;path.append(cur)
        d=len(path)-1
        def rec(i,k):  # send k pebbles from path[i] to path[i+1..] end
            pass
        # standard: need 2^d at x. do recursively
        def push(i,n):  # move n pebbles' worth from path[i] to end (n=2^(d-i))
            if i==d: return
            for _ in range(n//2): mv(path[i],path[i+1])
            push(i+1,n//2)
        push(0,2**d)
    def can(x): return arr[x]>=2**pc(x^v)
    if b%2==0:
        for _ in range(b//2): mv(u,v)
    elif b==1 or b==3:
        need=2 if b==1 else 1
        while arr[v]<need:
            ok=[x for x in S_F0 if x!=v and arr[x]>=2**pc(x^v)]
            if not ok: return None
            deliver(ok[0])
        if b==1:
            mv(v,u);mv(u,v)
        else:
            mv(u,v);mv(v,u);mv(u,v)
    else:
        for _ in range(b//2): mv(u,v)
        mv(v,u);mv(u,v)
    assert arr[u]==0
    return sum(arr)
random.seed(1)
bad=0;n=0;minrem=999
for _ in range(200000):
    # random 4 occupied in F0 (bit4=0), partner v random
    v=random.randrange(16); u=v|16
    S=random.sample(range(16),4)
    b=random.choice([1,3,1,3,2,5,7,random.randrange(1,40)])
    rest=63-b
    if rest<4: continue
    cuts=sorted(random.sample(range(1,rest),3)) if random.random()<.6 else None
    if cuts is None:
        # skewed: put most on one
        big=random.randrange(4);a=[1]*4;a[big]=rest-3
        if random.random()<.5:
            a=[random.randrange(1,4) for _ in range(4)];a[random.randrange(4)]+=rest-sum(a)
            if min(a)<1:continue
    else:
        a=[cuts[0],cuts[1]-cuts[0],cuts[2]-cuts[1],rest-cuts[2]]
    n+=1
    r=run(S,u,v,a,b)
    if r is None or r<31: bad+=1; print('BAD',S,v,a,b,r); 
    else: minrem=min(minrem,r)
print(n,bad,minrem)
