// Independent re-implementation: 0/1/2 preparatory legal moves then full halfcube absorption by explicit simulation.
#include <bits/stdc++.h>
using namespace std;
typedef array<int,32> A;
static const int R[22][5]={{0,1,2,28,31},{0,1,2,29,30},{0,1,2,29,31},{0,1,6,24,31},{0,1,6,25,30},{0,1,6,26,29},{0,1,6,26,31},{0,1,6,27,29},{0,1,6,27,30},{0,1,6,27,31},{0,1,6,30,31},{0,1,14,22,27},{0,1,14,22,31},{0,3,5,24,30},{0,3,5,24,31},{0,3,5,25,30},{0,3,5,26,28},{0,3,12,21,26},{0,3,12,21,27},{0,3,12,21,31},{0,3,12,23,29},{0,3,13,21,26}};
static const int W[22]={320,320,640,480,960,1920,1920,960,1920,1920,480,1920,960,960,960,320,960,960,1920,1920,384,960};
static inline void mv(A&a,int u,int v){assert(a[u]>=2);a[u]-=2;a[v]++;}
// returns true if absorbing face {x: bit(x,ax)==src} into opposite face succeeds with >=31 stones left
static bool absorb(const A&orig,int ax,int src){
  A a=orig;
  for(int x=0;x<32;x++){
    if(((x>>ax)&1)!=src||a[x]==0)continue;
    int y=x^(1<<ax);int b=a[x];
    if(b%2==0){for(int i=0;i<b/2;i++)mv(a,x,y);}
    else if(b>=5){for(int i=0;i<b/2;i++)mv(a,x,y);mv(a,y,x);mv(a,x,y);}
    else if(b==3){ if(a[y]<1)return false; mv(a,x,y);mv(a,y,x);mv(a,x,y);}
    else { if(a[y]<2)return false; mv(a,y,x);mv(a,x,y);}
  }
  int s=0;for(int x=0;x<32;x++){s+=a[x]; if(((x>>ax)&1)==src && a[x]!=0)return false;}
  return s>=31;
}
static bool fold(const A&a){for(int ax=0;ax<5;ax++)for(int s=0;s<2;s++)if(absorb(a,ax,s))return true;return false;}
int main(){
  uint64_t tot=0,b0=0,b1=0,b2=0,un=0;
  FILE*f=fopen("my_residual.bin","wb");
  for(int s=0;s<22;s++){
    uint64_t c0=0,c1=0,c2=0,cu=0;
    for(int a1=1;a1<60;a1++)for(int a2=1;a1+a2<61;a2++)for(int a3=1;a1+a2+a3<62;a3++)for(int a4=1;a1+a2+a3+a4<63;a4++){
      int a5=63-a1-a2-a3-a4;
      A a{};a[R[s][0]]=a1;a[R[s][1]]=a2;a[R[s][2]]=a3;a[R[s][3]]=a4;a[R[s][4]]=a5;
      bool ok=false;int lvl=0;
      if(fold(a)){ok=true;lvl=0;}
      if(!ok){
        for(int x=0;x<32&&!ok;x++)if(a[x]>=2)for(int i=0;i<5&&!ok;i++){
          A b=a;mv(b,x,x^(1<<i));
          if(fold(b)){ok=true;lvl=1;}
        }
      }
      if(!ok){
        for(int x=0;x<32&&!ok;x++)if(a[x]>=2)for(int i=0;i<5&&!ok;i++){
          A b=a;mv(b,x,x^(1<<i));
          for(int x2=0;x2<32&&!ok;x2++)if(b[x2]>=2)for(int j=0;j<5&&!ok;j++){
            A c=b;mv(c,x2,x2^(1<<j));
            if(fold(c)){ok=true;lvl=2;}
          }
        }
      }
      if(!ok){cu++;unsigned char r[6]={(unsigned char)s,(unsigned char)a1,(unsigned char)a2,(unsigned char)a3,(unsigned char)a4,(unsigned char)a5};fwrite(r,1,6,f);}
      else if(lvl==0)c0++;else if(lvl==1)c1++;else c2++;
    }
    assert(c0+c1+c2+cu==557845);
    printf("orbit %d w=%d base=%llu one=%llu two=%llu unres=%llu\n",s,W[s],c0,c1,c2,cu);fflush(stdout);
    tot+=557845ull*W[s];b0+=c0*W[s];b1+=c1*W[s];b2+=c2*W[s];un+=cu*W[s];
  }
  fclose(f);
  printf("WEIGHTED total=%llu base=%llu one=%llu two=%llu unres=%llu proven=%llu\n",tot,b0,b1,b2,un,b0+b1+b2);
}
