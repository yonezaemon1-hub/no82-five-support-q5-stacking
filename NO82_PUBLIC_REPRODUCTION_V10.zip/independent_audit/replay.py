import csv, json, itertools, collections
B='/tmp/claude-0/aud/ex/'
V14=B+'NO82_Q5_FIVE_SUPPORT_V14_PRIVATE_HOLD/NO82_Q5_FIVE_SUPPORT_V14_PRIVATE_HOLD/'
V15=B+'NO82_Q5_FIVE_SUPPORT_V15_PRIVATE_AUDIT_PENDING/NO82_Q5_FIVE_SUPPORT_V15_PRIVATE_AUDIT_PENDING/'
REPS=[(0,1,6,26,29),(0,1,6,26,31),(0,1,6,27,30),(0,1,6,27,31),(0,1,14,22,27),(0,3,12,21,27),(0,3,12,21,31),(0,1,6,25,30),(0,1,6,27,29),(0,1,14,22,31),(0,3,5,24,30),(0,3,5,24,31),(0,3,5,26,28),(0,3,12,21,26),(0,3,13,21,26),(0,1,2,29,31),(0,1,6,24,31),(0,1,6,30,31),(0,3,12,23,29),(0,1,2,28,31),(0,1,2,29,30),(0,3,5,25,30)]
W=[1920]*7+[960]*8+[640,480,480,384,320,320,320]
def legal(a,u,v):
    if u<0 or u>31 or v<0 or v>31 or bin(u^v).count('1')!=1 or a[u]<2: return False
    a[u]-=2;a[v]+=1;return True
th=open(V14+'data/residual_2.bin','rb').read()
resid={tuple(th[i:i+6]) for i in range(0,len(th),6)}
# faces check: all stones in a Q4 face and >=31
def face_ok(a):
    s=sum(a)
    for ax in range(5):
        for side in (0,1):
            if sum(a[x] for x in range(32) if (x>>ax)&1==side)==s: return s>=31
    return False
def absorb(a0):
    # independent absorb: returns number of ops and final array, or None
    best=None
    for ax in range(5):
        for src in (0,1):
            a=list(a0);ok=True
            for x in range(32):
                if (x>>ax)&1!=src or a[x]==0: continue
                y=x^(1<<ax);b=a[x]
                if b%2==0: seq=[(x,y)]*(b//2)
                elif b>=5: seq=[(x,y)]*(b//2)+[(y,x),(x,y)]
                elif b==3: seq=[(x,y),(y,x),(x,y)]
                else: seq=[(y,x),(x,y)]
                for u,v in seq:
                    if not legal(a,u,v): ok=False;break
                if not ok:break
            if ok and face_ok(a): return a
    return None
# ---- v1.4
seen=set();nprep=0;wt=0;minleft=99
for row in csv.reader(open(V14+'data/all_certificates.csv')):
    if row[0]=='orbit_index0': continue
    r=tuple(int(x) for x in row[:6]);n=int(row[6]);mvs=[tuple(map(int,p.split('-'))) for p in row[7:]]
    assert len(mvs)==n and r in resid and r not in seen
    seen.add(r);a=[0]*32
    for x,c in zip(REPS[r[0]],r[1:]): a[x]=c
    assert sum(a)==63 and all(c>0 for c in r[1:])
    for u,v in mvs: assert legal(a,u,v),r
    f=absorb(a); assert f is not None,r
    minleft=min(minleft,sum(f)); nprep+=n; wt+=W[r[0]]
print('v14 certs',len(seen),'weight',wt,'prep moves',nprep,'min stones after fold',minleft)
left=resid-seen
print('leftover',len(left),sum(W[r[0]] for r in left))
# ---- 10-cycle (own check)
def has_c10(S):
    S=set(S);start=min(S)
    def dfs(path,vis):
        if len(path)==10: return bin(path[-1]^start).count('1')==1 and S<=vis
        for k in range(5):
            w=path[-1]^(1<<k)
            if w in vis: continue
            if dfs(path+[w],vis|{w}): return True
        return False
    return dfs([start],{start})
c10=set()
for r in left:
    if sorted(r[1:])==[1,1,1,1,59] and has_c10(REPS[r[0]]): c10.add(r)
print('c10 rows',len(c10),sum(W[r[0]] for r in c10))
# any (59,1,1,1,1)-type rows in leftover not on C10?
other=[r for r in left if sorted(r[1:])==[1,1,1,1,59] and r not in c10]
print('59-type not on c10:',len(other))
rest=left-c10
print('rest',len(rest),sum(W[r[0]] for r in rest))
# ---- v1.5
rows={}
tot=0;nm=0;direct=0;red=0;wd=0;wr=0
for line in open(V15+'data/move_certificates_236.jsonl'):
    j=json.loads(line);r=(j['orbit_1_based']-1,)+tuple(j['stones'])
    assert r in rest and r not in rows
    assert tuple(j['vertices'])==REPS[r[0]] and sum(j['stones'])==63 and min(j['stones'])>0
    a=[0]*32
    for x,c in zip(j['vertices'],j['stones']):a[x]=c
    for u,v in j['moves']: assert legal(a,u,v),r
    assert a==j['final'] and sum(a)==63-len(j['moves'])
    nm+=len(j['moves'])
    if sum(1 for c in a if c)==1: direct+=1; wd+=W[r[0]]; kind='direct'
    else:
        assert face_ok(a),r; red+=1; wr+=W[r[0]]; kind='face'
    rows[r]=kind
print('v15 certs',len(rows),'moves',nm,'direct',direct,wd,'face',red,wr)
assert set(rows)==rest
print('RESIDUAL PARTITION EXACT: 17737 = 17496 + 5 + 236 ; weights',sum(W[r[0]] for r in resid), wt+3520+wd+wr)
