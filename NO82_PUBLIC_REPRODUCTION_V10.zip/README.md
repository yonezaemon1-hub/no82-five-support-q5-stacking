# No.82 — Five-support stacking on the five-dimensional cube

Ryutaro Yonezu · unrefereed preprint, 2026-11-23 · All rights reserved.

Main result (conditional on the included finite certificates): every configuration of 63 pebbles on **exactly five occupied vertices** of Q5 is stackable. The Q4 exact finite result, stack(Q4)=31, is a prerequisite. The full stack(Q5)=63 claim and an all-dimensions formula are **not** established.

Independent AI mathematical audit: reported PASS in scope. Author Windows 10 reproduction: PASS (2026-11-23); independent provenance check of the original Windows log: INCONCLUSIVE. NOVELTY INCONCLUSIVE; REFERENCES PARTIAL; NOT HUMAN PEER REVIEWED. No formal verification. The auditor findings Markdown is an author-supplied transcription, not an auditor-signed original.

`paper/` contains the preprint PDF and LaTeX. `q4/` and `q5/` contain finite certificate data and checker source; `independent_recount/` contains independent enumeration source, and `independent_audit/` contains the auditor-supplied independent reimplementation source without raw logs. `proof/` contains the inherited analytic proof. `SHA256SUMS.txt` verifies every included file. For Windows PowerShell 5.1, run `q4/verify_windows.ps1` and `q5/RUN_WINDOWS.ps1` separately after extracting the archive; both require Python 3 and g++ C++17. This public release was selected from the authorized private candidate; internal parent archives, raw logs, cached bytecode, and author machine transcripts were omitted.
