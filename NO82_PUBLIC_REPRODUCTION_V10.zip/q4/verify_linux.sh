#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
sha256sum -c SHA256SUMS.txt | tail -1
g++ -O3 -std=c++17 prior_v01/code/audit_stack_cube.cpp -o /tmp/no82_q3_check
/tmp/no82_q3_check 3 15 | tee logs/linux_q3_15.log | grep -q 'CONFIGURATIONS=170544 NON_STACKABLE=0'
python code/verify_bridge_options_independent.py
g++ -O3 -std=c++17 code/scan_centered.cpp -o /tmp/no82_scan_v05
/tmp/no82_scan_v05 > logs/linux_scan_v05.log 2>&1
grep -q 'total 41677241 no_donor 18256453 one_donor 20917157 multi 2468310 fail 35321' logs/linux_scan_v05.log
g++ -O3 -std=c++17 code/bridge_scan.cpp -o /tmp/no82_bridge_v05
/tmp/no82_bridge_v05 > logs/linux_bridge_v05.log 2>&1
grep -q 'bridge scan input=35321 additionally_solved=35303 remain=18' logs/linux_bridge_v05.log
python code/verify_final18.py
# Verify frozen predecessor splits, scripts and exact donor profiles.
g++ -O3 -std=c++17 prior_v04/code/q4_general_profile_glue.cpp -o /tmp/no82_glue_v04
for ab in '9 22' '10 21' '11 20' '12 19' '10 20' '10 18' '11 19' '11 17' '12 18' '13 17'; do
  read -r a b <<< "$ab"
  /tmp/no82_glue_v04 "$a" "$b" > "logs/linux_glue_${a}_${b}.log" 2>&1
  grep -q 'no_glue_profiles=0' "logs/linux_glue_${a}_${b}.log"
done
for stem in q4_balanced_15_15 q4_balanced_15_16 q4_conditional_14_16; do
  g++ -O3 -std=c++17 "prior_v04/prior_v03/code/${stem}.cpp" -o "/tmp/no82_${stem}"
  "/tmp/no82_${stem}" > "logs/linux_${stem}.log" 2>&1
  grep -q 'failing=0' "logs/linux_${stem}.log"
done
python prior_v04/code/verify_donor_masks_independent.py
python prior_v04/code/verify_count_independent.py
python prior_v04/code/verify_pair_transfer.py
python prior_v04/prior_v03/code/verify_caseII_witnesses.py prior_v04/prior_v03/certificate/q4_13_18_exception_caseII_128_witnesses.json
sha256sum -c SHA256SUMS.txt | tail -1
echo 'Q4 EXACT v0.5 FINITE CHECKS PASS; GENERAL ALL-n FORMULA HOLD / WINDOWS UNTESTED / PRIVATE'
