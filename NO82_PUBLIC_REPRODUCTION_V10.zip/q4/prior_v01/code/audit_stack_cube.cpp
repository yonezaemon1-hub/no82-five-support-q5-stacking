// Research No.82 discovery v0.1 — exact finite enumeration, PRIVATE / HOLD.
// Pure C++17, no external libraries. Handles Q_1, Q_2, Q_3 (8 vertices maximum).
// States store each count in a 6-bit field; every legal move lowers total by 1.
// A state is stackable iff it has one occupied vertex OR at least one legal
// move leads to a stackable state. Memo values: 1=stackable, 2=not stackable.
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include <unordered_map>
#include <vector>
using namespace std;
int n, N;
vector<vector<int>> neighbors;
unordered_map<uint64_t, uint8_t> cache;
static uint64_t at(uint64_t s, int v) { return (s>>(6*v))&63ULL; }
static bool solve(uint64_t s) {
    auto it=cache.find(s);
    // CORRECT: a cached value of 2 represents FALSE, not TRUE.
    if(it!=cache.end()) return it->second == 1;
    int occupied=0;
    for(int v=0;v<N;++v) occupied += (at(s,v)>0);
    if(occupied==1) {cache[s]=1; return true;}
    for(int u=0;u<N;++u) if(at(s,u)>=2)
        for(int v:neighbors[u]) {
            uint64_t nxt = s-(2ULL<<(6*u))+(1ULL<<(6*v));
            if(solve(nxt)) {cache[s]=1; return true;}
        }
    cache[s]=2; return false;
}
static void configurations(int v,int remain,uint64_t state,
                           uint64_t& tested,uint64_t& bad,uint64_t& witness) {
    if(v==N-1) {
        uint64_t s=state+((uint64_t)remain<<(6*v));
        ++tested;
        if(!solve(s)) {++bad; if(witness==UINT64_MAX) witness=s;}
        return;
    }
    for(int k=0;k<=remain;++k)
        configurations(v+1,remain-k,state+((uint64_t)k<<(6*v)),tested,bad,witness);
}
int main(int argc,char**argv) {
    if(argc!=3) {cerr<<"Usage: audit_stack_cube DIMENSION TOTAL_PEBBLES\n";return 2;}
    n=atoi(argv[1]); int total=atoi(argv[2]);
    if(n<1 || n>3 || total<1 || total>30) {
        cerr<<"Use dimension 1..3 and total stones 1..30.\n";return 2;
    }
    N=1<<n; neighbors.resize(N);
    for(int v=0;v<N;++v) for(int k=0;k<n;++k) neighbors[v].push_back(v^(1<<k));
    uint64_t tested=0,bad=0,witness=UINT64_MAX;
    configurations(0,total,0,tested,bad,witness);
    cout<<"Q"<<n<<" TOTAL="<<total<<" CONFIGURATIONS="<<tested
        <<" NON_STACKABLE="<<bad<<" MEMO_STATES="<<cache.size();
    if(bad) {
        cout<<" FIRST_WITNESS=";
        for(int i=0;i<N;++i) {if(i)cout<<",";cout<<at(witness,i);}
    }
    cout<<"\n";
    return 0;
}
