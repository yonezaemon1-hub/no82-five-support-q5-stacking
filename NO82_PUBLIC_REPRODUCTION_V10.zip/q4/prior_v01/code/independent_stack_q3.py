"""Research No.82: independently enumerate all Q3 configurations at 14 and 15 pebbles.
PRIVATE / HOLD. Uses Python tuples, no C++ state packing or third-party packages.
"""
from functools import lru_cache
from math import comb

N = 8
neighbors = {v: tuple(v ^ (1 << k) for k in range(3)) for v in range(N)}

@lru_cache(None)
def stackable(state):
    if sum(x > 0 for x in state) == 1:
        return True
    for u, x in enumerate(state):
        if x < 2:
            continue
        for v in neighbors[u]:
            next_state = list(state)
            next_state[u] -= 2
            next_state[v] += 1
            if stackable(tuple(next_state)):
                return True
    return False

def configurations(total, position=0):
    if position == N - 1:
        yield (total,)
        return
    for first in range(total + 1):
        for remaining in configurations(total - first, position + 1):
            yield (first,) + remaining

for stones in (14, 15):
    bad, tested = [], 0
    for state in configurations(stones):
        tested += 1
        if not stackable(state):
            bad.append(state)
    assert tested == comb(stones + N - 1, N - 1)
    assert len(bad) == (8 if stones == 14 else 0)
    print(f"Q3 TOTAL={stones} CONFIGURATIONS={tested} NON_STACKABLE={len(bad)} "
          f"MEMO_STATES={stackable.cache_info().currsize}")
    if bad:
        print("ALL_FAILURE_WITNESSES:")
        for p in bad:
            print(" ", p)
