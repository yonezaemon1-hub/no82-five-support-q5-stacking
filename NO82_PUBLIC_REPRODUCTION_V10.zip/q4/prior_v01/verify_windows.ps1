# PowerShell 5.1, MinGW g++ and Python 3.x. LOCAL-only; no network access.
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$bin = Join-Path $PSScriptRoot 'audit_stack_cube.exe'
& g++ -std=c++17 -O2 .\code\audit_stack_cube.cpp -o $bin
if ($LASTEXITCODE -ne 0) { throw "g++ compilation failed" }
$expected = @(
  @('1','2','3','1'),
  @('1','3','4','0'),
  @('2','6','84','6'),
  @('2','7','120','0'),
  @('3','14','116280','8'),
  @('3','15','170544','0')
)
foreach ($case in $expected) {
  $actual = & $bin $case[0] $case[1]
  if ($LASTEXITCODE -ne 0) { throw "C++ runtime failed" }
  $pattern = '^Q' + $case[0] + ' TOTAL=' + $case[1] + ' CONFIGURATIONS=' + $case[2] + ' NON_STACKABLE=' + $case[3] + '( |$)'
  if ($actual -notmatch $pattern) { throw "MISMATCH: $actual" }
  Write-Host "PASS $actual"
}
& python .\code\independent_stack_q3.py
if ($LASTEXITCODE -ne 0) { throw "Python independent audit failed" }
Write-Host 'NO82 DISCOVERY FINITE AUDIT PASS (no general theorem)' 
