"""Exact dynamic-programming count of Q4 31-pebble configurations outside all [9,22] coordinate splits."""
from collections import defaultdict
from math import comb
S={(0,0,0,0,0):1}
for v in range(1,16):
    T=defaultdict(int)
    for (t,*m),ct in S.items():
        cap=min([31-t]+[8-m[j] for j in range(4) if (v>>j)&1])
        for x in range(cap+1):
            k=(t+x,)+tuple(m[j]+x*((v>>j)&1) for j in range(4))
            T[k]+=ct
    S=T
per_center=sum(S.values())
all_31=comb(46,15)
remaining=16*per_center
covered=all_31-remaining
assert (per_center,remaining,all_31,covered)==(41677241,666835856,511738760544,511071924688)
print('COUNT_INDEPENDENT PASS')
print('TOTAL_Q4_31',all_31)
print('NO_BALANCED_SPLIT_PER_CENTER',per_center)
print('NO_BALANCED_SPLIT_ALL_CENTERS',remaining)
print('SPLIT_9_TO_22_CERTIFIED_CLASS',covered)
print('PROPORTION',f'{100*covered/all_31:.12f}%')
