#include <bits/stdc++.h>
using namespace std;
constexpr int B=9, LIM=31;
int main(){const int S=6561; vector<long long>a(S*(LIM+1)),b(S*(LIM+1));a[0]=1;
for(int v=1;v<16;v++){
 fill(b.begin(),b.end(),0);
 for(int index=0;index<S;index++){
  int d[4]={index%9,(index/9)%9,(index/81)%9,(index/729)%9};
  int mx=31;for(int bit=0;bit<4;bit++)if(v>>bit&1)mx=min(mx,8-d[bit]);
  if(mx<0)continue;
  for(int t=0;t<=31;t++){auto val=a[index*32+t];if(!val)continue;
   for(int x=0;x<=mx && t+x<=31;x++){
    int index2=index;
    for(int bit=0;bit<4;bit++)if(v>>bit&1)index2+=x*(int)pow(9,bit);
    b[index2*32+t+x]+=val;
   }
  }
 }
 a.swap(b);
}
long long count=0;for(auto x:a)count+=x;
cout<<"count_per_canonical_center="<<count<<"\n";
cout<<"total_unbalanced_with_unique_center="<<count*16<<"\n";
cout<<"ratio="<<100.0*count*16/511738760544.0<<"%\n";
}
