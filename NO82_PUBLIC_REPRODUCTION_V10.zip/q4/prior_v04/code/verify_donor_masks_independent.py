"""Independent pure-Python exhaustive Q3 donor-mask audit t=9..12."""
from functools import lru_cache
from collections import Counter

@lru_cache(None)
def stackable(state):
    if sum(x>0 for x in state)==1:
        return True
    for u,x in enumerate(state):
        if x>=2:
            for v in (u^1,u^2,u^4):
                nxt=list(state);nxt[u]-=2;nxt[v]+=1
                if stackable(tuple(nxt)):
                    return True
    return False

def comps(n,t,p=()):
    if n==1:
        yield p+(t,)
        return
    for k in range(t+1):
        yield from comps(n-1,t-k,p+(k,))

parity_mask=(0b01101001,0b10010110)
expected={9:(600,160,104),10:(468,0,48),11:(296,0,0),12:(126,0,0)}
for t in range(9,13):
    cls=Counter();bad=0
    for c in comps(8,t):
        if stackable(c):continue
        bad+=1
        mask=0
        for v in range(8):
            d=list(c);d[v]+=1
            if not stackable(tuple(d)):
                mask |=1<<v
        if mask==0:k=0
        elif mask.bit_count()==1:k=1
        elif mask in parity_mask:k=4
        else:raise AssertionError((t,c,mask,'unapproved bad donor mask'))
        cls[k]+=1
    observed=(cls[0],cls[1],cls[4])
    assert observed==expected[t],(t,observed,expected[t])
    print(f'PASS Q3_t{t} nonstackable={bad}, bad_donors_0_1_4={observed}')
print('PASS: no other bad-donor masks; cache',stackable.cache_info())
