#include <bits/stdc++.h>
using namespace std;
int main(int argc,char **argv){int n=argc>1?atoi(argv[1]):3;int low=argc>2?atoi(argv[2]):(3*(1<<n)-3),hi=argc>3?atoi(argv[3]):(3*(1<<n)-2);int N=1<<n;
vector<unsigned char> a(N);unordered_map<uint64_t,char> memo;memo.reserve(10000000);
function<uint64_t()>key=[&](){uint64_t k=0;for(int j=0;j<N;j++)k|=uint64_t(a[j])<<(j*6);return k;};
function<bool()>solve=[&](){int supp=0,loc=-1;for(int j=0;j<N;j++)if(a[j]){supp++;loc=j;}if(supp==1&&loc==0)return true; // target only
uint64_t k=key();auto it=memo.find(k);if(it!=memo.end())return bool(it->second);
for(int u=0;u<N;u++)if(a[u]>=2){a[u]-=2;for(int bit=0;bit<n;bit++){int v=u^(1<<bit);a[v]++;if(solve()){a[v]--;a[u]+=2;memo.emplace(k,1);return true;}a[v]--;}a[u]+=2;}
memo.emplace(k,0);return false;};
function<void(int,int,long long&,long long&,string&)> rec=[&](int pos,int left,long long&tot,long long&fails,string &first){if(pos==N-1){a[pos]=left;tot++;if(!solve()){fails++;if(first.empty()){for(auto x:a)first+=to_string(int(x))+",";}}return;}for(int x=0;x<=left;x++){a[pos]=x;rec(pos+1,left-x,tot,fails,first);}};
for(int t=low;t<=hi;t++){long long tot=0,bad=0;string ex;rec(0,t,tot,bad,ex);cout<<"N="<<N<<" t="<<t<<" total="<<tot<<" missing_root0="<<bad<<" first="<<ex<<" memo="<<memo.size()<<"\n";}}
