#include <bits/stdc++.h>
using namespace std;
struct Prof{array<uint8_t,8> z{};bool operator==(Prof const&v) const{return z==v.z;}};
struct H{size_t operator()(Prof const&v)const {uint64_t h=0;for(auto x:v.z)h=(h<<5)|x;return h;}};
struct Solver{
 array<uint8_t,8>a{};unordered_map<uint64_t,Prof>memo;unordered_map<Prof,long long,H>freqA,freqB;
 uint64_t key(){uint64_t h=0;for(auto x:a)h=(h<<5)|x;return h;}
 Prof eval(){Prof ans{};int support=0,pos=-1;for(int i=0;i<8;i++)if(a[i]){support++;pos=i;}if(support==1)ans.z[pos]=a[pos];auto k=key();auto it=memo.find(k);if(it!=memo.end())return it->second;
 for(int u=0;u<8;u++)if(a[u]>=2){a[u]-=2;for(int bit=0;bit<3;bit++){int v=u^(1<<bit);a[v]++;auto tmp=eval();for(int i=0;i<8;i++)ans.z[i]=max(ans.z[i],tmp.z[i]);a[v]--;}a[u]+=2;}
 memo.emplace(k,ans);return ans;}
 void rec(int i,int rem,unordered_map<Prof,long long,H>&Freq){if(i==7){a[i]=rem;Freq[eval()]++;return;}for(int j=0;j<=rem;j++){a[i]=j;rec(i+1,rem-j,Freq);}}
};
struct Path{
 array<unordered_map<uint64_t,uint8_t>,5>memo;
 uint64_t key(vector<int> const&a){uint64_t h=0;for(int x:a)h=(h<<6)|x;return h;}
 bool eval(vector<int>&a,int d){int supp=0;for(auto x:a)supp+=x>0;if(supp<=1)return true;
 auto k=key(a);auto it=memo[d].find(k);if(it!=memo[d].end())return bool(it->second);
 for(int u=0;u<=d;u++)if(a[u]>=2){a[u]-=2;for(int v:{u-1,u+1})if(v>=0&&v<=d){a[v]++;if(eval(a,d)){a[v]--;a[u]+=2;memo[d][k]=1;return true;}a[v]--;}a[u]+=2;}memo[d][k]=0;return false;}
 bool merge(int p,int q,int d){vector<int>a(d+1);a[0]=p;a[d]=q;return eval(a,d);}
};
int main(int argc,char**argv){if(argc<3){cerr<<"usage sizeA sizeB\n";return 1;}int na=atoi(argv[1]),nb=atoi(argv[2]);Solver S;S.memo.reserve(8000000);S.rec(0,na,S.freqA);cerr<<"A size="<<na<<" classes="<<S.freqA.size()<<" states="<<S.memo.size()<<"\n";S.rec(0,nb,S.freqB);cerr<<"B size="<<nb<<" classes="<<S.freqB.size()<<" states="<<S.memo.size()<<"\n";
 Path D;bool mp[5][32][32]{};for(int d=1;d<=4;d++)for(int p=1;p<32;p++)for(int q=1;q<32;q++)mp[d][p][q]=D.merge(p,q,d);
 long long good=0,bad=0,empty=0,glue_fail=0, profpairs=0;int printed=0;
 for(auto const&[x,fx]:S.freqA)for(auto const&[y,fy]:S.freqB){profpairs++;bool ok=false;bool ex=true;for(auto p:x.z)if(p)ex=false;for(auto p:y.z)if(p)ex=false; // flag either missing handled separately below
 if(!any_of(x.z.begin(),x.z.end(),[](uint8_t v){return v>0;}) || !any_of(y.z.begin(),y.z.end(),[](uint8_t v){return v>0;})) {empty+=fx*fy;bad+=fx*fy;continue;}
 for(int u=0;u<8&&!ok;u++)if(x.z[u])for(int v=0;v<8;v++)if(y.z[v]){int dist=1+__builtin_popcount((unsigned)(u^v));if(mp[dist][x.z[u]][y.z[v]]){ok=true;break;}}
 if(ok)good+=fx*fy;else{glue_fail+=fx*fy;bad+=fx*fy;if(printed++<2){cerr<<"MISS PROFILE p=";for(auto v:x.z)cerr<<(int)v<<",";cerr<<" q=";for(auto v:y.z)cerr<<(int)v<<",";cerr<<"\n";}}}
 cout<<"a="<<na<<" b="<<nb<<" profile_pairs="<<profpairs<<" good_initial="<<good<<" missed_initial="<<bad<<" missing_by_unstackable_side="<<empty<<" no_glue_profiles="<<glue_fail<<"\n";
}
