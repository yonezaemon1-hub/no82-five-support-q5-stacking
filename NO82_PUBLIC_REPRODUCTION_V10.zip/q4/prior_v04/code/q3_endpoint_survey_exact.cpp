#include <bits/stdc++.h>
using namespace std;
struct P{array<uint8_t,8> a{};};
struct D{array<uint8_t,8> a{};unordered_map<uint64_t,P> memo;uint64_t key(){uint64_t k=0;for(auto x:a)k=(k<<5)|x;return k;}
P go(){int num=0,last=0;for(int i=0;i<8;i++)if(a[i]){num++;last=i;} P p; if(num<=1 && num)p.a[last]=a[last];
uint64_t k=key();auto it=memo.find(k);if(it!=memo.end())return it->second;
for(int u=0;u<8;u++)if(a[u]>=2){a[u]-=2;for(int bit=0;bit<3;bit++){int v=u^(1<<bit);a[v]++;auto z=go();for(int x=0;x<8;x++)p.a[x]=max(p.a[x],z.a[x]);a[v]--;}a[u]+=2;}memo.emplace(k,p);return p;}
void rec(int i,int left,int tot,vector<long long>&countZeros,long long &total,array<int,8>&minReach,array<long long,9>&masks){if(i==7){a[i]=left;auto p=go();int mask=0;for(int j=0;j<8;j++)if(p.a[j])mask|=1<<j;int n=__builtin_popcount((unsigned)mask);masks[n]++;for(int j=0;j<8;j++){if(!p.a[j])countZeros[j]++;minReach[j]=min(minReach[j],(int)p.a[j]);} total++;return;}for(int v=0;v<=left;v++){a[i]=v;rec(i+1,left-v,tot,countZeros,total,minReach,masks);}}
};
int main(int argc,char**argv){int lo=argc>1?atoi(argv[1]):15,hi=argc>2?atoi(argv[2]):21;D d;d.memo.reserve(3800000);for(int t=lo;t<=hi;t++){vector<long long>z(8);long long count=0;array<int,8>mins;mins.fill(100);array<long long,9>ms{};d.rec(0,t,t,z,count,mins,ms);cerr<<"T="<<t<<" count="<<count<<" memo="<<d.memo.size()<<" unstack_any_target="<<z[0]<<" #endpoint bins=";for(int i=0;i<=8;i++)cerr<<i<<":"<<ms[i]<<",";cerr<<"\n";}}
