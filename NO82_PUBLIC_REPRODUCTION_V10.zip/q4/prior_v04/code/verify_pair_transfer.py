from functools import lru_cache
@lru_cache(None)
def reach_a(a,b):
    o={a} if b==0 else set()
    if a>=2: o |= reach_a(a-2,b+1)
    if b>=2: o |= reach_a(a+1,b-2)
    return frozenset(o)
checks=0
for a in range(32):
 for b in range(32-a):
  if b%2==0:
   expected=a+b//2
   assert expected in reach_a(a,b),(a,b,expected)
  elif a+b//2>=2:
   expected=a+b//2-1
   assert expected in reach_a(a,b),(a,b,expected)
  checks+=1
print('PAIR_TRANSFER_CHECK PASS pairs=',checks,'cached_states=',reach_a.cache_info().currsize)
