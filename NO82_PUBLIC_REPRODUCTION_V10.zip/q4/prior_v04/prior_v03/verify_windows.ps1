$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
Write-Host 'NO82 FINITE v0.3 verification: PUBLIC RELEASE v1.0'
# Manifest verification is optional on first run if this file is edited locally.
Get-Content .\SHA256SUMS.txt | ForEach-Object {
    $parts = $_ -split '  ', 2
    if ($parts.Count -ne 2) { throw "Malformed SHA256 line: $_" }
    $expected=$parts[0].ToLowerInvariant()
    $path=Join-Path $PSScriptRoot ($parts[1] -replace '/', '\')
    if (-not (Test-Path -LiteralPath $path)) { throw "Missing file $path" }
    $actual=(Get-FileHash -Algorithm SHA256 -LiteralPath $path).Hash.ToLowerInvariant()
    if ($actual -ne $expected) { throw "SHA256 FAIL $path" }
    Write-Host "SHA256 PASS $($parts[1])"
}
$names=@('q4_balanced_15_16','q4_balanced_15_15','q4_conditional_14_16')
foreach ($name in $names) {
    & g++ -O3 -std=c++17 ".\code\$name.cpp" -o "$env:TEMP\$name.exe"
    if ($LASTEXITCODE -ne 0) { throw "compile FAIL $name" }
    $txt = (& "$env:TEMP\$name.exe" 2>&1 | Out-String)
    if ($LASTEXITCODE -ne 0) { throw "run FAIL $name" }
    if ($txt -notmatch 'failing=0') { throw "FINITE FAIL $name" }
    Write-Host "FINITE PASS $name"
    Write-Host $txt
}
& python .\code\verify_caseII_witnesses.py
if ($LASTEXITCODE -ne 0) { throw 'CASE II CERTIFICATE FAIL' }
Write-Host 'NO82 FINITE VERIFICATION PASS (NOT GENERAL THEOREM)'
