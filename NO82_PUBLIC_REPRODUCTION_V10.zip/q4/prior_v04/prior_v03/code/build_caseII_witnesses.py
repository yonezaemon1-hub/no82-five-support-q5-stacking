#!/usr/bin/env python3
"""Generate and directly replay 128 constructive Q4 certificates.
CASE II: layer A has 18 pebbles, a pile at 0 and singles elsewhere;
layer B has 12 pebbles at vertex 8 and one at vertex 15.
No assumed theorem about Q4 used to generate/verify witnesses.
"""
import json
from functools import lru_cache
from pathlib import Path

@lru_cache(None)
def profiles(c):
    supp=[i for i,x in enumerate(c) if x]
    if len(supp)==1:return ((supp[0],c[supp[0]]),)
    out={}
    for u in supp:
        if c[u]<2:continue
        for k in range(3):
            v=u^(1<<k)
            a=list(c);a[u]-=2;a[v]+=1
            for w,p in profiles(tuple(a)):
                out[w]=max(out.get(w,0),p)
    return tuple(sorted(out.items()))

def trace_profile(c,root,num):
    r={}
    state=tuple(c)
    moves=[]
    while len([i for i,x in enumerate(state) if x])>1:
        found=None
        for u,x in enumerate(state):
            if x<2:continue
            for k in range(3):
                v=u^(1<<k)
                a=list(state);a[u]-=2;a[v]+=1
                if dict(profiles(tuple(a))).get(root,0)>=num:
                    found=(u,v,tuple(a));break
            if found:break
        assert found,(state,root,num)
        u,v,state=found
        moves.append([u,v])
    assert state[root]==num and sum(x>0 for x in state)==1
    return moves

@lru_cache(None)
def path_can(c):
    if sum(x>0 for x in c)==1:return True
    for u,x in enumerate(c):
        if x<2:continue
        for v in (u-1,u+1):
            if 0<=v<len(c):
                a=list(c);a[u]-=2;a[v]+=1
                if path_can(tuple(a)):return True
    return False

def path_trace(p,q,d):
    a=(p,)+(0,)*(d-1)+(q,)
    assert path_can(a)
    moves=[]
    while sum(x>0 for x in a)>1:
        found=None
        for u,x in enumerate(a):
            if x<2:continue
            for v in (u-1,u+1):
                if 0<=v<len(a):
                    b=list(a);b[u]-=2;b[v]+=1
                    if path_can(tuple(b)):
                        found=(u,v,tuple(b));break
            if found:break
        assert found
        u,v,a=found
        moves.append([u,v])
    return moves

def replay(mask,moves):
    a=[0]*16;a[0]=18-mask.bit_count()
    for v in range(1,8):a[v]=(mask>>(v-1))&1
    a[8]=12;a[15]=1
    assert sum(a)==31
    for u,v in moves:
        assert (u^v).bit_count()==1 and a[u]>=2,(mask,u,v,a)
        a[u]-=2;a[v]+=1
    assert sum(x>0 for x in a)==1,(mask,a)

out={};totalmoves=0
for mask in range(128):
    A=[0]*8;A[0]=18-mask.bit_count()
    for u in range(1,8):A[u]=(mask>>(u-1))&1
    B=[0]*8;B[0]=12;B[7]=1
    chosen=None
    for u,p in profiles(tuple(A)):
        for v,q in profiles(tuple(B)):
            d=1+(u^v).bit_count()
            if path_can((p,)+(0,)*(d-1)+(q,)):
                chosen=u,p,v,q,d
                break
        if chosen:break
    assert chosen,mask
    u,p,v,q,d=chosen
    ma=trace_profile(A,u,p)
    mb=[[x+8,y+8] for x,y in trace_profile(B,v,q)]
    path=[u,u+8]
    j=u
    for k in range(3):
        if (u^v)>>k &1:
            j^=1<<k
            path.append(j+8)
    assert path[-1]==v+8 and len(path)==d+1
    mc=[[path[x],path[y]] for x,y in path_trace(p,q,d)]
    moves=ma+mb+mc
    replay(mask,moves)
    out[str(mask)]=moves
    totalmoves+=len(moves)

p=Path(__file__).resolve().parent.parent/'certificate'/'q4_13_18_exception_caseII_128_witnesses.json'
p.write_text(json.dumps(out,separators=(',',':'))+'\n',encoding='utf-8')
print('Q4_CASEII_WITNESSES=128/128 PASS')
print('Q4_CASEII_LEGAL_MOVES_REPLAYED=',totalmoves)
print('DP_STATS:',profiles.cache_info(),path_can.cache_info())
print('OUTPUT=',p)
