#!/usr/bin/env python3
"""Independent, search-free verifier: Q4 128 exceptional configs in split (18,13).
Checks exact witness-set coverage, initial counts, adjacency, legality, final support.
This checker never calls the witness-building search code.
"""
import json
import sys
from pathlib import Path
p = Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent.parent/'certificate'/'q4_13_18_exception_caseII_128_witnesses.json'
raw=json.loads(p.read_text(encoding='utf-8'))
assert set(raw)=={str(i) for i in range(128)},'Missing / extra mask key'
all_moves=0
for mask in range(128):
    a=[0]*16
    a[0]=18-mask.bit_count()
    for v in range(1,8):a[v]=(mask>>(v-1))&1
    a[8]=12
    a[15]=1
    assert sum(a)==31
    seq=raw[str(mask)]
    for u,v in seq:
        assert isinstance(u,int) and isinstance(v,int)
        assert 0<=u<16 and 0<=v<16
        assert (u^v).bit_count()==1,('not adjacent',mask,u,v)
        assert a[u]>=2,('illegal source',mask,u,v,a)
        a[u]-=2;a[v]+=1
        all_moves+=1
    assert sum(x>0 for x in a)==1,('not stacked',mask,a)
print(f'CASEII_MASKS=128, LEGAL_MOVES={all_moves}, RESULT=PASS')
