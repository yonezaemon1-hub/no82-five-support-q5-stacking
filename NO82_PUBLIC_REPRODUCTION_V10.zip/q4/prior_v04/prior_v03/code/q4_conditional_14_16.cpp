#include <bits/stdc++.h>
using namespace std;
struct Profile{array<uint8_t,8>a{};bool operator==(const Profile&b)const{return a==b.a;}};
struct Hash{size_t operator()(const Profile&v)const{uint64_t k=0;for(auto x:v.a)k=k*32+x;return hash<uint64_t>{}(k);}};
struct Dp{
 unordered_map<uint64_t,Profile>memo;unordered_map<Profile,int,Hash>f15,f16;
 array<int,8>a{};array<array<int,3>,8>adj{};
 Dp(){for(int u=0;u<8;u++)for(int k=0;k<3;k++)adj[u][k]=u^(1<<k);memo.reserve(1600000);}
 uint64_t key(){uint64_t k=0;for(int v:a)k=k*32+v;return k;}
 Profile roots(){int supp=0,pos=-1;for(int i=0;i<8;i++)if(a[i])supp++,pos=i;Profile ret{};if(supp<=1){if(supp==1)ret.a[pos]=a[pos];return ret;}
 auto key0=key();auto it=memo.find(key0);if(it!=memo.end())return it->second;
 for(int u=0;u<8;u++)if(a[u]>=2){a[u]-=2;for(int v:adj[u]){a[v]++;auto z=roots();for(int i=0;i<8;i++)ret.a[i]=max(ret.a[i],z.a[i]);a[v]--;}a[u]+=2;}
 memo.emplace(key0,ret);return ret;}
 void enumerate(int idx,int total,unordered_map<Profile,int,Hash>&F){if(idx==7){a[idx]=total;F[roots()]++;return;}for(int i=0;i<=total;i++){a[idx]=i;enumerate(idx+1,total-i,F);}}
};
struct PathDp{
 // map of integer base 64 states. one per distance.
 array<unordered_map<uint64_t,uint8_t>,5>memo;
 uint64_t key(const vector<int> &a){uint64_t v=0;for(int x:a)v=(v<<6)+x;return v;}
 bool go(vector<int>&a,int d){int supp=0;for(int x:a)supp+=x>0;if(supp<=1)return true;
 auto key0=key(a);auto it=memo[d].find(key0);if(it!=memo[d].end())return it->second;
 for(int u=0;u<=d;u++)if(a[u]>=2){a[u]-=2;for(int v:{u-1,u+1})if(0<=v&&v<=d){a[v]++;if(go(a,d)){a[v]--;a[u]+=2;memo[d][key0]=1;return true;}a[v]--;}a[u]+=2;}
 memo[d][key0]=0;return false;}
 bool check(int p,int q,int d){vector<int>a(d+1);a[0]=p;a[d]=q;return go(a,d);}
};
int mask(const Profile&v){int m=0;for(int i=0;i<8;i++)if(v.a[i])m|=1<<i;return m;}
int main(){
 Dp D;D.enumerate(0,14,D.f15);cerr<<"Q3_size15="<<D.f15.size()<<" profiles, memo="<<D.memo.size()<<"\n";D.enumerate(0,16,D.f16);cerr<<"Q3_size16="<<D.f16.size()<<" profiles, memo="<<D.memo.size()<<"\n";
 PathDp path;bool merge[5][17][17]{};for(int d=1;d<=4;d++)for(int p=1;p<=16;p++)for(int q=1;q<=16;q++)merge[d][p][q]=path.check(p,q,d);
 array<vector<pair<Profile,int>>,256> buckets15,buckets16;
 for(auto [p,f]:D.f15)buckets15[mask(p)].push_back({p,f});for(auto [p,f]:D.f16)buckets16[mask(p)].push_back({p,f});
 long long tested=0,passing=0,failing=0,covered=0,overlap=0,disjoint=0;
 int fail_m=0,fail_n=0; Profile fail_p{},fail_q{};
 for(int ma=1;ma<256;ma++)for(int mb=1;mb<256;mb++){
  auto &A=buckets15[ma],&B=buckets16[mb];if(A.empty()||B.empty())continue;
  if(ma&mb){for(auto &a:A)for(auto &b:B){overlap++; covered+=(long long)a.second*b.second; }continue;}
  for(auto &a:A)for(auto &b:B){tested++;disjoint++; bool ok=false;
   for(int u=0;u<8 && !ok;u++)if(a.first.a[u])for(int v=0;v<8;v++)if(b.first.a[v]){
     int d=1+__builtin_popcount((unsigned)(u^v));
     if(merge[d][a.first.a[u]][b.first.a[v]]){ok=true;break;}
   }
   if(ok){passing++;covered+=(long long)a.second*b.second;}else{failing++;if(failing==1){fail_m=ma;fail_n=mb;fail_p=a.first;fail_q=b.first;}}
  }
 }
 cout<<"profile15="<<D.f15.size()<<" profile16="<<D.f16.size()<<"\n";
 cout<<"overlap_profile_pairs="<<overlap<<" disjoint_profile_pairs="<<disjoint<<" tested="<<tested<<" passing="<<passing<<" failing="<<failing<<"\n";
 cout<<"certified_initial_pairs="<<covered<<" total_initial_pairs="<<116280LL*245157LL<<"\n";
 if(failing){cout<<"FIRST_MISSED ma="<<fail_m<<" mb="<<fail_n<<" p=";for(int v:fail_p.a)cout<<v<<",";cout<<" q=";for(int v:fail_q.a)cout<<v<<",";cout<<"\n";}
 for(int d=1;d<=4;d++)cerr<<"pathmemo distance "<<d<<" states "<<path.memo[d].size()<<"\n";
}
