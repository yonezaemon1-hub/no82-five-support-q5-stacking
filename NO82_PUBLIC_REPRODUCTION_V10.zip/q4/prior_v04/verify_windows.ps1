# No.82 v0.4 strict Windows PowerShell reproducibility check. Does not publish anything.
param([switch]$SkipPriorRerun)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
New-Item -ItemType Directory -Force -Path '.\build_windows', '.\logs_windows' | Out-Null
Write-Host 'No82 v0.4 START (PUBLIC RELEASE v1.0)'
# Verify package file identity before execution.
$items = Get-Content '.\SHA256SUMS.txt'
foreach ($line in $items) {
  if ($line -notmatch '^([0-9a-fA-F]{64})\s+(.+)$') { throw "Bad manifest line: $line" }
  $expected = $Matches[1].ToLowerInvariant()
  $rel = $Matches[2].Replace('/', '\')
  if (-not (Test-Path -LiteralPath $rel)) { throw "Missing file: $rel" }
  $actual = (Get-FileHash -LiteralPath $rel -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($actual -ne $expected) { throw "SHA256 FAIL: $rel" }
}
Write-Host 'SHA256 PASS'
# Native C++ emits progress on stderr; keep stdout separately to avoid PS5.1 NativeCommandError.
$source = '.\code\q4_general_profile_glue.cpp'
$exe = '.\build_windows\q4_general_profile_glue.exe'
& g++ -O3 -std=c++17 $source -o $exe
if ($LASTEXITCODE -ne 0) { throw 'C++ compile failed: glue' }
$cases = @(@(9,22),@(10,21),@(11,20),@(12,19),@(10,20),@(10,18),@(11,19),@(11,17),@(12,18),@(13,17))
foreach ($c in $cases) {
  $x=[int]$c[0]; $y=[int]$c[1]
  $res = & $exe $x $y
  if ($LASTEXITCODE -ne 0) { throw "GLUE C++ runtime FAIL: $x $y" }
  $res | Set-Content -Encoding UTF8 ('.\logs_windows\glue_{0}_{1}.log' -f $x,$y)
  $summary = ($res | Where-Object { $_ -match '^a=\d+ b=\d+ ' } | Select-Object -Last 1)
  if (-not $summary -or $summary -notmatch 'no_glue_profiles=0') { throw "GLUE FAIL: $x $y" }
  $bad = [long]([regex]::Match($summary, ' missed_initial=(\d+)').Groups[1].Value)
  $empty = [long]([regex]::Match($summary, ' missing_by_unstackable_side=(\d+)').Groups[1].Value)
  if ($bad -ne $empty) { throw "Unexpected nongluing profile: $x $y" }
  Write-Host "GLUE PASS $x+$y"
}
& python '.\code\verify_donor_masks_independent.py'
if ($LASTEXITCODE -ne 0) { throw 'Independent donor classification FAIL' }
& python '.\code\verify_count_independent.py'
if ($LASTEXITCODE -ne 0) { throw 'Independent count FAIL' }
& python '.\code\verify_pair_transfer.py'
if ($LASTEXITCODE -ne 0) { throw 'Pair transfer audit FAIL' }
& g++ -O3 -std=c++17 '.\code\count_unbalanced_q4.cpp' -o '.\build_windows\count_unbalanced_q4.exe'
if ($LASTEXITCODE -ne 0) { throw 'Count C++ compile FAIL' }
$r = & '.\build_windows\count_unbalanced_q4.exe'
if ($LASTEXITCODE -ne 0 -or ($r -join ' ') -notmatch 'count_per_canonical_center=41677241') { throw 'Count C++ FAIL' }
Write-Host 'COUNT CPP PASS'
& g++ -O3 -std=c++17 '.\code\root0_indep_q3.cpp' -o '.\build_windows\root0_indep_q3.exe'
if ($LASTEXITCODE -ne 0) { throw 'Rooted C++ compile FAIL' }
$r = & '.\build_windows\root0_indep_q3.exe' 3 21 22
if ($LASTEXITCODE -ne 0 -or ($r -join ' ') -notmatch 't=22 total=1560780 missing_root0=0') { throw 'Rooted Q3 FAIL' }
Write-Host 'ROOTED Q3 PASS'
& python '.\prior_v03\code\verify_caseII_witnesses.py' '.\prior_v03\certificate\q4_13_18_exception_caseII_128_witnesses.json'
if ($LASTEXITCODE -ne 0) { throw 'Prior v0.3 128-witness replay FAIL' }
if (-not $SkipPriorRerun) {
  foreach ($stem in @('q4_balanced_15_15','q4_balanced_15_16','q4_conditional_14_16')) {
    $oldexe = '.\build_windows\'+$stem+'.exe'
    & g++ -O3 -std=c++17 ('.\prior_v03\code\'+$stem+'.cpp') -o $oldexe
    if ($LASTEXITCODE -ne 0) { throw "Prior compile FAIL: $stem" }
    $out = & $oldexe
    if ($LASTEXITCODE -ne 0) { throw "Prior runtime FAIL: $stem" }
    $out | Set-Content -Encoding UTF8 ('.\logs_windows\'+$stem+'.log')
    if (($out -join ' ') -notmatch 'failing=0') { throw "Prior finite FAIL: $stem" }
    Write-Host "PRIOR PASS $stem"
  }
}
Write-Host 'No82 v0.4 WINDOWS LOCAL FINITE CHECKS PASS — GENERAL THEOREM REMAINS HOLD'
