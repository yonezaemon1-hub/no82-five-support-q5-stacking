"""Independent checker: trusts no generator code, only the path-list payload in each row."""
from pathlib import Path
import csv,json
root=Path(__file__).resolve().parent.parent
rows=list(csv.DictReader((root/'bridge_options.csv').open()))
certs=[json.loads(s) for s in (root/'bridge_option_path_witnesses.jsonl').read_text().splitlines()]
assert len(rows)==len(certs)==28278
seen=set()
for row,d in zip(rows,certs):
 R,I,p,z=[int(row[k]) for k in ('R','injectMask','paths','zeros')]
 assert (R,I,p,z)==(d['R'],d['injectMask'],d['paths'],d['zeros'])
 assert (R,I,p,z) not in seen
 seen.add((R,I,p,z))
 paths=d['witnessPaths']
 assert len(paths)==p
 covered=0;inj=0;zeros=0
 for path in paths:
  assert len(path)>0
  assert (R>>path[0])&1 and (R>>path[-1])&1
  inj|=1<<path[0]
  for j,v in enumerate(path):
   assert 0<=v<8 and not((covered>>v)&1),(R,path,v)
   covered|=1<<v
   if not((R>>v)&1):inj|=1<<v;zeros+=1
   if j:assert ((path[j-1]^v).bit_count()==1),(R,path)
 assert (covered&R)==R,(R,covered)
 assert (covered&~R).bit_count()==z==zeros,(R,covered,z)
 assert inj==I,(R,I,inj,paths)
print('BRIDGE_OPTION_CERTIFICATE PASS:',len(certs),'rows, independent graph/partition/mask replay; errors=0')
