#include <bits/stdc++.h>
using namespace std;
using ull=unsigned long long; using U=unsigned __int128;
struct H{size_t operator()(U k)const noexcept{ull lo=(ull)k,hi=(ull)(k>>64);lo^=hi*0x9e3779b97f4a7c15ULL;lo^=lo>>33;lo*=0xff51afd7ed558ccdULL;return size_t(lo^(lo>>33));}};
int a[16]={21,1,0,1,0,1,1,0,0,1,1,0,1,0,0,3};
int bestRoot=0;long long limit=3000000,seen=0,prune=0;bool capped=false;
unordered_set<U,H> bad;vector<pair<int,int>> plan;
U key(){U r=0;for(int v=0;v<16;v++)r=(r<<5)|a[v];return r;}
bool dfs(int total){
 int supp=0,pos=-1;
 for(int v=0;v<16;v++)if(a[v]){supp++;pos=v;}
 if(supp==1)return (bestRoot==-1 || pos==bestRoot);
 if(++seen>limit){capped=true;return false;}
 U id=key();if(bad.count(id))return false;
 // Weighted singleton invariant: any frozen pebble must be the final stack root.
 int frozen=-1;
 for(int r=0;r<16;r++)if(a[r]==1){int mass=0;for(int v=0;v<16;v++)if(v!=r&&a[v])mass+=a[v]*(16>>__builtin_popcount(unsigned(r^v)));
  if(mass<16){if(frozen!=-1 && frozen!=r){prune++;bad.insert(id);return false;} frozen=r;}
 }
 if(bestRoot>=0 && frozen>=0 && frozen!=bestRoot){prune++;bad.insert(id);return false;}
 if(bestRoot>=0){int mass=0;for(int v=0;v<16;v++)mass+=a[v]*(16>>__builtin_popcount(unsigned(bestRoot^v)));
 if(mass<16){prune++;bad.insert(id);return false;}}
 struct Move{int u,v,score;};Move opts[64];int n=0;
 for(int u=0;u<16;u++)if(a[u]>=2)for(int k=0;k<4;k++){
  int v=u^(1<<k),score=0;
  score+=40*(a[u]==2 && a[v]>=1);
  score+=20*(a[u]==2);
  score+=10*(a[v]>=1);
  if(bestRoot>=0){int da=__builtin_popcount(unsigned(u^bestRoot)),db=__builtin_popcount(unsigned(v^bestRoot));score+=8*(da>db);score-=8*(da<db);}
  score+=min(a[v],4);score-=min(a[u],8)/2;
  opts[n++]={u,v,score};
 }
 sort(opts,opts+n,[](Move x,Move y){return x.score>y.score;});
 for(int i=0;i<n;i++){
  auto [u,v,s]=opts[i]; a[u]-=2;a[v]++;
  if(dfs(total-1)){plan.emplace_back(u,v);a[v]--;a[u]+=2;return true;}
  a[v]--;a[u]+=2;
  if(capped)break;
 }
 if(!capped)bad.insert(id);
 return false;
}
int main(int argc,char**argv){if(argc>1)bestRoot=atoi(argv[1]);if(argc>2)limit=atoll(argv[2]);bad.reserve(min(20000000LL,limit));bool ok=dfs(31);cerr<<"result "<<ok<<" root="<<bestRoot<<" visited="<<seen<<" prune="<<prune<<" dead="<<bad.size()<<" capped="<<capped<<"\n";if(ok){reverse(plan.begin(),plan.end());for(auto [u,v]:plan)cout<<u<<" "<<v<<"\n";}}
