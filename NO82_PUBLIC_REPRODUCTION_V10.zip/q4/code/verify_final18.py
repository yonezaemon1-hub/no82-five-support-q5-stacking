"""Exact independent legal-move replay and byte-for-byte enumeration matching (No.82 v0.5)."""
from pathlib import Path
import json,struct
root=Path(__file__).resolve().parent.parent
records=json.loads((root/'final18_full_witnesses.json').read_text())
raw=(root/'bridge_fail.bin').read_bytes()
assert len(raw)%64==0
actual=[list(struct.unpack('<16i',raw[i:i+64])) for i in range(0,len(raw),64)]
assert len(actual)==len(records)==18, (len(actual),len(records))
replayed=0
for i,rec in enumerate(records):
    assert rec['id']==i
    initial=rec['initial']
    assert sum(initial)==31 and initial==actual[i],(i,initial,actual[i])
    assert len(initial)==16 and all(isinstance(x,int) and x>=0 for x in initial)
    c=initial[:]
    for j,move in enumerate(rec['moves']):
        assert isinstance(move,list) and len(move)==2
        u,v=move
        assert 0<=u<16 and 0<=v<16 and (u^v).bit_count()==1,(i,j,u,v)
        assert c[u]>=2,(i,j,u,v,c)
        c[u]-=2;c[v]+=1;replayed+=1
    assert sum(x>0 for x in c)==1 and c[rec['final_root']]>0,(i,c)
    assert c==rec['final_configuration']
print(f'Q4_FINAL18_INDEPENDENT_REPLAY PASS cases={len(records)} legal_moves={replayed} invalid=0')
