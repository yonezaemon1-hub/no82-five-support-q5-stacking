#define main original_scan_main
#include "scan_centered.cpp"
#undef main
struct Option{uint8_t inject,p,z;};vector<Option> bridgeOpts[256];
void readOpts(){ifstream file("bridge_options.csv");string s;getline(file,s);while(getline(file,s)){replace(s.begin(),s.end(),',',' ');istringstream in(s);int R,I,p,z;in>>R>>I>>p>>z;bridgeOpts[R].push_back({(uint8_t)I,(uint8_t)p,(uint8_t)z});}}
int solveBridge(){
 for(int k=0;k<4;k++){
  int A[8],R=0,q=0,r=0;
  for(int x=0;x<8;x++){int av=idx2[k][x],bv=av^(1<<k);int b=c[bv];A[x]=c[av]+b/2;q+=b/2;if(b&1){R|=1<<x;r++;}}
  for(auto o:bridgeOpts[R]){
   int budget=31-q-r-o.p-2*o.z-15;
   if(budget<0)break;
   int rich=0;for(int x=0;x<8;x++)if(A[x]>=2)rich|=1<<x;
   if((o.inject&~rich)==0)return 1;
   for(int v=0;v<4;v++)if(greedy_multi(A,o.inject,budget,v))return 2;
  }
 }return 0;
}
int main(){build();readOpts();ifstream in("multidonor_fail.bin",ios::binary);long long total=0,solved=0,not_solved=0;int first[16]{};long long bycenter[32][2]={};static ofstream lost("bridge_fail.bin",ios::binary);
 while(in.read(reinterpret_cast<char*>(c),sizeof(c))){total++;if(solveBridge()){solved++;bycenter[c[0]][0]++;}else{not_solved++;bycenter[c[0]][1]++;lost.write(reinterpret_cast<const char*>(c),sizeof(c));if(!first[0])memcpy(first,c,sizeof(c));}}
 cerr<<"bridge scan input="<<total<<" additionally_solved="<<solved<<" remain="<<not_solved<<"\nexample ";for(int v=0;v<16;v++)cerr<<first[v]<<(v<15?',':'\n');for(int u=0;u<32;u++)if(bycenter[u][1])cerr<<u<<" "<<bycenter[u][0]<<" "<<bycenter[u][1]<<"\n";
}
