"""Generate explicit disjoint-path witnesses for all bridge option rows and independently replay their combinatorial conditions."""
from functools import lru_cache
from pathlib import Path
import csv,json
root=Path(__file__).resolve().parent.parent
src=list(csv.DictReader((root/'bridge_options.csv').open()))
paths=[]
for start in range(8):
 def traverse(path,visited):
  paths.append((tuple(path),visited,1<<path[0],1<<path[-1]))
  for b in (1,2,4):
   x=path[-1]^b
   if not (visited>>x&1):traverse(path+[x],visited|(1<<x))
 traverse([start],1<<start)
by_R={}
for R in range(256):
 eligible=[]
 for path,pm,s,e in paths:
  if s&R and e&R: eligible.append((path,pm,pm&R,pm&~R,s))
 @lru_cache(None)
 def solve(rem,used):
  if not rem:return {(0,0,0):()}
  bit=rem&-rem;result={}
  for path,pm,part,zeros,start in eligible:
   if not(part&bit) or (used&pm) or (part&~rem):continue
   for (I,p,z),tail in solve(rem^part,used|pm).items():
    key=(I|start|zeros,p+1,z+zeros.bit_count())
    if key not in result:result[key]=(path,)+tail
  return result
 by_R[R]=solve(R,0)
assert sum(len(x) for x in by_R.values())==28278
with (root/'bridge_option_path_witnesses.jsonl').open('w') as f:
 for row in src:
  R,I,p,z=(int(row[k]) for k in ['R','injectMask','paths','zeros'])
  ps=by_R[R].get((I,p,z))
  assert ps is not None,(R,I,p,z)
  f.write(json.dumps({'R':R,'injectMask':I,'paths':p,'zeros':z,'witnessPaths':ps},separators=(',',':'))+'\n')
print('GENERATED',len(src),'explicit path decompositions')
