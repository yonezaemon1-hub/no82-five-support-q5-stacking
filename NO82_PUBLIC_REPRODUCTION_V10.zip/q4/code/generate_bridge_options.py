from functools import lru_cache
from pathlib import Path
P=Path(__file__).resolve().parent.parent/'bridge_options.csv'
paths=[]
for start in range(8):
    def visit(path,seen):
        mask=seen
        paths.append((mask,1<<start,1<<path[-1]))
        for bit in range(3):
            v=path[-1]^(1<<bit)
            if not seen>>v&1: visit(path+(v,),seen|(1<<v))
    visit((start,),1<<start)
paths=sorted(set(paths))
@lru_cache(None)
def options(R):
    cand=[]
    for pm,start,end in paths:
        if (start&R)==0 or (end&R)==0:continue
        cand.append((pm,pm&R,pm&~R,start))
    @lru_cache(None)
    def go(rem,used):
        if rem==0:return frozenset(((0,0,0),))
        bit=rem&-rem
        out=set()
        for pm,part,zeros,start in cand:
            if not part&bit or pm&used or part&~rem:continue
            for inj,p,z in go(rem^part,used|pm):
                out.add((inj|start|zeros,p+1,z+zeros.bit_count()))
        return frozenset(out)
    return go(R,0)
with P.open('w') as f:
    f.write('R,injectMask,paths,zeros\n')
    n=0
    for R in range(256):
        for inj,p,z in sorted(options(R),key=lambda t:(t[1]+2*t[2],t[1],t[2],t[0])):
            f.write(f'{R},{inj},{p},{z}\n');n+=1
print('path_graph_items=',len(paths),'cover_options=',n,'output=',P)
