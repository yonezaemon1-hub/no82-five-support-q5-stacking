#include <bits/stdc++.h>
using namespace std;using ll=long long;
int c[16]={},coord[4]={},idx2[4][8],dd[8][8];
vector<int> covers[256]; bool canpath[256][8]={}, cov[256][256]={};
ll total=0,success_no_donor=0,success_one_donor=0,success_multi_donor=0,fail=0;ll hist[32][4]={};int first[16]={};
void enumerate_paths(int start,int cur,int mask){canpath[mask][start]=true;for(int bit=0;bit<3;bit++){int next=cur^(1<<bit);if(!(mask>>next&1))enumerate_paths(start,next,mask|(1<<next));}}
void build(){for(int k=0;k<4;k++)for(int x=0;x<8;x++){int v=0,j=0;for(int bit=0;bit<4;bit++)if(bit!=k){v|=((x>>j)&1)<<bit;j++;}idx2[k][x]=v;}
 for(int i=0;i<8;i++)for(int j=0;j<8;j++)dd[i][j]=__builtin_popcount(unsigned(i^j));
 for(int i=0;i<8;i++)enumerate_paths(i,i,1<<i);
 cov[0][0]=true; covers[0].push_back(0);
 for(int M=1;M<256;M++){int first=__builtin_ctz(unsigned(M));for(int pm=1;pm<=M;pm++)if((pm&M)==pm && (pm&(1<<first))){int rest=M^pm;for(int st=0;st<8;st++)if(canpath[pm][st])for(int masks=0;masks<256;masks++)if(cov[rest][masks])cov[M][masks|(1<<st)]=true;}
 for(int s=1;s<256;s++)if(cov[M][s])covers[M].push_back(s);
 sort(covers[M].begin(),covers[M].end(),[](int a,int b){return __builtin_popcount(unsigned(a))<__builtin_popcount(unsigned(b));});}
}
bool greedy_multi(const int A[8], int sm, int budget, int variant) {
   int cap[8],need[8]={}; int nodes[16],ni=0;
   for(int x=0;x<8;x++){cap[x]=max(0,A[x]-((sm>>x&1)?2:0));
     if(sm>>x&1 && A[x]<2){int d=2-A[x];need[x]=d;for(int t=0;t<d;t++)nodes[ni++]=x;}}
   if(!ni)return true;
   auto bestdist=[&](int s){int q=99;for(int u=0;u<8;u++)if(cap[u]>=(1<<dd[u][s]))q=min(q,dd[u][s]);return q;};
   sort(nodes,nodes+ni,[&](int a,int b){
      if(variant==0)return bestdist(a)>bestdist(b);
      if(variant==1)return bestdist(a)<bestdist(b);
      if(variant==2)return a>b;
      return a<b;});
   int cost=0;
   for(int i=0;i<ni;i++){
     int s=nodes[i],uBest=-1,weightBest=INT_MAX;
     for(int u=0;u<8;u++){
       int weight=(1<<dd[u][s]);if(cap[u]<weight)continue;
       int key=(weight-1)*32;
       if(variant==0 || variant==1)key-=min(cap[u],31);
       if(variant==2)key+=cap[u];
       if(key<weightBest){weightBest=key;uBest=u;}
     }
     if(uBest<0)return false;
     int w=1<<dd[uBest][s];cap[uBest]-=w;cost+=w-1;
     if(cost>budget)return false;
   }
   return true;
}
int solve(){for(int k=0;k<4;k++){
 int A[8],rMask=0,q=0,r=0;
 for(int x=0;x<8;x++){int av=idx2[k][x],bv=av^(1<<k); int b=c[bv];A[x]=c[av]+b/2;q+=b/2;if(b&1){r++;rMask|=1<<x;}}
 int rich=0;for(int x=0;x<8;x++)if(A[x]>=2)rich|=1<<x;
 for(int sm:covers[rMask]){int p=__builtin_popcount(unsigned(sm));int left0=31-q-r-p;if(left0<15)break;
   if((sm&~rich)==0)return 1;
   for(int donor=0;donor<8;donor++)if(A[donor]>=2){int demand=0,cost=0;for(int s=0;s<8;s++)if((sm>>s&1)&&A[s]<2){int delta=2-A[s],base=1<<dd[donor][s];demand+=delta*base;cost+=delta*(base-1);}
      int reserve=(sm>>donor&1)?2:0;
      if(A[donor]>=demand+reserve && left0-cost>=15)return 2;
   }
   for(int variant=0;variant<4;variant++)if(greedy_multi(A,sm,left0-15,variant))return 3;
 }
 }return 0;}
void inspect(int rem){c[0]=rem;total++;int ans=solve();if(ans){hist[rem][ans-1]++;if(ans==1)success_no_donor++;else if(ans==2)success_one_donor++;else {success_multi_donor++;}return;}fail++;static ofstream bad("multidonor_fail.bin",ios::binary);bad.write(reinterpret_cast<const char*>(c),sizeof(c));hist[rem][3]++;if(!first[0])for(int i=0;i<16;i++)first[i]=c[i];}
void rec(int v,int rem){if(v==16){inspect(rem);return;}int lim=rem;for(int k=0;k<4;k++)if(v>>k&1)lim=min(lim,8-coord[k]);for(int x=0;x<=lim;x++){c[v]=x;for(int k=0;k<4;k++)if(v>>k&1)coord[k]+=x;rec(v+1,rem-x);for(int k=0;k<4;k++)if(v>>k&1)coord[k]-=x;}}
int main(){build();int count=0;for(int M=0;M<256;M++)count+=covers[M].size();cerr<<"total_cover_options="<<count<<"\n";rec(1,31);cerr<<"total "<<total<<" no_donor "<<success_no_donor<<" one_donor "<<success_one_donor<<" multi "<<success_multi_donor<<" fail "<<fail<<" frac="<<(double)(success_no_donor+success_one_donor+success_multi_donor)/total<<"\n";cerr<<"example unsolved: ";for(int i=0;i<16;i++)cerr<<first[i]<<(i<15?',':'\n');for(int i=0;i<32;i++)if(hist[i][3])cerr<<i<<" "<<hist[i][0]<<" "<<hist[i][1]<<" "<<hist[i][2]<<" "<<hist[i][3]<<"\n";return 0;}
