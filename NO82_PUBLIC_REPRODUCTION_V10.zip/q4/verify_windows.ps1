# No.82 v0.5 — Complete PUBLIC RELEASE v1.0 reproducibility run, Windows PowerShell 5.1.
# No GitHub / Zenodo / email / internet activity is performed.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
Write-Host 'No82 Q4 EXACT v0.5 START — PUBLIC RELEASE v1.0'

function Test-Manifest {
    foreach ($line in Get-Content '.\SHA256SUMS.txt') {
        if ($line -notmatch '^([0-9a-fA-F]{64})\s+(.+)$') { throw "Malformed SHA256 record: $line" }
        $hash = $Matches[1].ToLowerInvariant()
        $path = $Matches[2].Replace('/','\')
        if (-not (Test-Path -LiteralPath $path)) { throw "File missing: $path" }
        if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $hash) { throw "SHA256 mismatch: $path" }
    }
    Write-Host 'PACKAGE SHA256 PASS'
}

Test-Manifest
New-Item -ItemType Directory -Force '.\build_windows', '.\logs_windows' | Out-Null

# Reexecute all frozen v0.4 and v0.3 prerequisite checks, including C++ profile tests.
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File '.\prior_v04\verify_windows.ps1'
if ($LASTEXITCODE -ne 0) { throw 'Prior v0.4 finite checks failed' }
Write-Host 'PRIOR v0.4 PASS'

# Exact Q3 baseline, 15 pebbles, 170,544 configurations.
& g++ -O3 -std=c++17 '.\prior_v01\code\audit_stack_cube.cpp' -o '.\build_windows\audit_stack_cube.exe'
if ($LASTEXITCODE -ne 0) { throw 'Q3 C++ compile failed' }
$q3 = & '.\build_windows\audit_stack_cube.exe' 3 15
if ($LASTEXITCODE -ne 0 -or ($q3 -join ' ') -notmatch 'CONFIGURATIONS=170544 NON_STACKABLE=0') { throw "Q3 verification FAIL: $q3" }
Write-Host 'Q3 15-pebble EXACT PASS'

& python '.\code\verify_bridge_options_independent.py'
if ($LASTEXITCODE -ne 0) { throw 'Bridge witness verification FAIL' }

& g++ -O3 -std=c++17 '.\code\scan_centered.cpp' -o '.\build_windows\scan_centered.exe'
if ($LASTEXITCODE -ne 0) { throw 'Centered-scan compile FAIL' }
$scanExe = (Resolve-Path '.\build_windows\scan_centered.exe').Path
$scanOut = Join-Path $root 'logs_windows\scan_centered_stdout.txt'
$scanErr = Join-Path $root 'logs_windows\scan_centered_stderr.txt'
$p = Start-Process -FilePath $scanExe -WorkingDirectory $root -RedirectStandardOutput $scanOut -RedirectStandardError $scanErr -PassThru -Wait
if ($p.ExitCode -ne 0) { throw 'Centered-scan runtime FAIL' }
$scan = Get-Content $scanErr -Raw
if ($scan -notmatch 'total 41677241 no_donor 18256453 one_donor 20917157 multi 2468310 fail 35321') { throw "Centered-scan count mismatch: $scan" }
Write-Host 'Q4 CENTERED 41,677,241 FULL SCAN PASS'

& g++ -O3 -std=c++17 '.\code\bridge_scan.cpp' -o '.\build_windows\bridge_scan.exe'
if ($LASTEXITCODE -ne 0) { throw 'Bridge-scan compile FAIL' }
$bridgeExe = (Resolve-Path '.\build_windows\bridge_scan.exe').Path
$bridgeOut = Join-Path $root 'logs_windows\bridge_scan_stdout.txt'
$bridgeErr = Join-Path $root 'logs_windows\bridge_scan_stderr.txt'
$p = Start-Process -FilePath $bridgeExe -WorkingDirectory $root -RedirectStandardOutput $bridgeOut -RedirectStandardError $bridgeErr -PassThru -Wait
if ($p.ExitCode -ne 0) { throw 'Bridge-scan runtime FAIL' }
$bridge = Get-Content $bridgeErr -Raw
if ($bridge -notmatch 'bridge scan input=35321 additionally_solved=35303 remain=18') { throw "Bridge-scan count mismatch: $bridge" }
Write-Host 'Q4 BRIDGE 35,303 ADDITIONAL CASES PASS'

& python '.\code\verify_final18.py'
if ($LASTEXITCODE -ne 0) { throw 'Last 18 independent move replay FAIL' }
Test-Manifest
Write-Host 'Q4 EXACT FINITE COMPUTER-ASSISTED CHECKS PASS — ALL-n FORMULA STILL HOLD'
Write-Host 'NOVELTY INCONCLUSIVE / WINDOWS PASS applies to this local run only / PRIVATE'
