# Research No.82 v1.5 — Conditional complete result on five-point supports of Q5

**Status: PRIVATE / AUDIT PENDING.** Date: 23 November 2026 JST.

## Conditional theorem

Let Q5 be the five-dimensional hypercube and consider configurations of exactly 63 pebbles on exactly five occupied vertices, using the move `u -> v` along a cube edge which consumes two pebbles at `u` and creates one at `v`. A configuration is *stackable* when a finite legal sequence leaves all surviving pebbles on a single vertex.

**Claim (conditional finite theorem):** Every such configuration is stackable, assuming (A1) the previously reported result that any 31-pebble configuration of Q4 is stackable; (A2) the earlier singleton-separation / constant-coordinate reductions for five-point Q5 supports; and (A3) the earlier v1.4 22-orbit exhaustive classification, its move certificates and the published even-cycle almost-stacked result used there. The v1.5 package does **not** independently audit (A1) or (A2).

The statement does **not** assert that all 63-pebble configurations of Q5 are stackable, nor the formula for arbitrary n.

## Exhaustive combinatorial partition

There are `binom(32,5) = 201376` support sets and `binom(62,4) = 557845` positive allocations on each, giving `112336594720` total configurations. The partition, with no double counting, is:

1. Inherited separable / constant-coordinate cases: `98912612640` (A2).
2. Earlier v1.4 two-step fold classification: `13408524160` (A1, A3).
3. Earlier v1.4 explicit move paths: `15259840` (A1, A3).
4. Earlier ten-cycle almost-stacked cases: `3520` (A3).
5. **New v1.5 remainder:** `194560` weighted configurations, encoded by precisely 236 representative configurations. No representative is omitted or repeated: the set difference between the archived v1.4 residual and all archived prior positive certificates equals exactly the provided v1.5 CSV. Hypercube automorphism-orbit sizes are recalculated by all bit permutations and bit flips.

## Constructive verification of all remaining 236 representatives

The JSONL certificate specifies five vertices, five positive counts summing to 63, each directed edge move in execution order, a final configuration, and a method.

**214 representatives / 183200 weighted cases:** an explicit legal sequence first supplies a missing parity correction to vertices of one Q4 face, then removes the opposite face via legal two-for-one moves. All stones lie on the target Q4 face afterward and at least 31 stones remain. Hence (A1) gives the final conclusion. This is a *conditional* reduction, not a direct Q5 stack certificate.

**4 representatives / 1280 weighted cases:** explicit rooted-tree move sequences directly leave the stones on one Q5 vertex.

**18 representatives / 10080 weighted cases:** an integer optimization model produced legal staged move schedules that directly leave the stones on one Q5 vertex. For each phase t, nonnegative integer move counts x(t,u,v) obey `2 sum_v x(t,u,v) <= a(t,u)` and `a(t+1,u) = a(t,u)-2 sum_v x(t,u,v)+sum_v x(t,v,u)`, with all non-root final counts zero. These stage inequalities make every stage executable independently of the incoming moves in that same stage. The explicit ordered moves, not solver status or optimality, are the proof certificates.

Two separate Python and C++17 replay implementations checked all **6963** ordered moves; every source had at least two pebbles at execution, each edge was a cube edge, conservation held, and the recorded final configurations were exact. The C++ code does not call the search algorithms or Python code. The Python verifier additionally checks the archived v1.4 residual set and the 22 support orbits.

## Auditor's critical checks

Independently challenge assumptions (A1), (A2) and the correctness/completeness of the v1.4 exhaustive two-step classification. Check that the 22 support orbits do cover every non-separable five-vertex support, and that no symmetry orbit is double-counted. Re-run the 236 certificates and verify every move and final classification. Inspect that all 214 Q4 reductions use the actual 31-pebble Q4 theorem, rather than an unsupported stronger fixed-target statement. Check whether the claimed result is already implied by prior literature; novelty remains inconclusive.

**Do not promote to FULL THEOREM PASS from replay results alone.** Publication remains HOLD pending external independent mathematical audit and author Windows-machine reproduction. All rights reserved. Not human peer reviewed. References partial.
