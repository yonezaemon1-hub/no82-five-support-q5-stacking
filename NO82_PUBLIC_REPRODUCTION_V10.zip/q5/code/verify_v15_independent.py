#!/usr/bin/env python3
"""No.82 v1.5: independent, standard-library-only certificate verifier.

This verifies legal pebbling moves for all remaining 236 representative
configurations on Q5, as well as completeness against v1.4's residual set.
It DOES NOT prove the inherited Q4 all-configurations theorem, the earlier
one-vs-four support reduction, or independent novelty.
"""
from pathlib import Path
from collections import Counter
import csv, itertools, json, math, hashlib

BASE=Path(__file__).resolve().parent.parent
DATA=BASE/'data'
EXPECT_ORBS=[1920]*7+[960]*8+[640,480,480,384,320,320,320]
ALL_22_SUPPORT_REPS=[
(0,1,6,26,29),(0,1,6,26,31),(0,1,6,27,30),(0,1,6,27,31),
(0,1,14,22,27),(0,3,12,21,27),(0,3,12,21,31),
(0,1,6,25,30),(0,1,6,27,29),(0,1,14,22,31),
(0,3,5,24,30),(0,3,5,24,31),(0,3,5,26,28),(0,3,12,21,26),
(0,3,13,21,26),(0,1,2,29,31),(0,1,6,24,31),(0,1,6,30,31),
(0,3,12,23,29),(0,1,2,28,31),(0,1,2,29,30),(0,3,5,25,30)
]

def sha256(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def verify_move_record(cert):
    verts=cert['vertices'];stones=cert['stones'];start=[0]*32
    assert len(verts)==len(stones)==5 and len(set(verts))==5
    assert all(isinstance(v,int) and 0<=v<32 for v in verts)
    assert all(isinstance(s,int) and s>0 for s in stones)
    assert sum(stones)==63
    for v,s in zip(verts,stones):start[v]=s
    a=start.copy()
    for step,(u,v) in enumerate(cert['moves']):
        assert isinstance(u,int) and isinstance(v,int), (cert['representative_index0'],step)
        assert 0<=u<32 and 0<=v<32 and (u^v).bit_count()==1, (cert['representative_index0'],step,'edge')
        assert a[u]>=2, (cert['representative_index0'],step,'insufficient',u,a[u])
        a[u]-=2;a[v]+=1
    assert a==cert['final'], ('final mismatch',cert['representative_index0'])
    assert sum(a)==63-len(cert['moves']) and sum(a)>0
    method=cert['method'];meta=cert['metadata']
    if method=='supply_and_fold':
        axis=meta['fold_axis'];side=meta['folded_side']
        assert 0<=axis<5 and side in (0,1)
        assert all(a[v]==0 for v in range(32) if (v>>axis)&1==side)
        assert sum(a)>=31, ('needs inherited Q4 theorem',cert['representative_index0'])
        assert any(a[v]>0 for v in range(32) if (v>>axis)&1!=side)
        return 'Q4_face',sum(a)
    if method in ('rooted_tree','staged_integer_program'):
        root=meta['root'];assert root in range(32)
        assert all(a[v]==0 for v in range(32) if v!=root), ('nonstacked',cert['representative_index0'])
        assert a[root]>=1
        return 'Q5_direct',a[root]
    raise AssertionError('unknown method '+method)

def has_c10(support):
    start=support[0];needed=set(support);path=[start];used={start}
    def dfs(v):
        if len(path)==10:
            return (v^start).bit_count()==1 and needed.issubset(used)
        if 10-len(path)<len(needed-used):return False
        for bit in range(5):
            w=v^(1<<bit)
            if w in used:continue
            path.append(w);used.add(w)
            if dfs(w):return True
            path.pop();used.remove(w)
        return False
    return dfs(start)

def complete_against_v14(certs):
    binary=(DATA/'prior_v14_residual_2.bin').read_bytes()
    assert len(binary)%6==0
    residual={tuple(binary[i:i+6]) for i in range(0,len(binary),6)}
    assert len(residual)==17737
    assert sum(EXPECT_ORBS[rec[0]] for rec in residual)==15457920
    prev=set()
    with (DATA/'prior_v14_all_certificates.csv').open(newline='') as f:
        for row in list(csv.reader(f))[1:]:
            item=tuple(map(int,row[:6]))
            assert item in residual and item not in prev
            prev.add(item)
    assert len(prev)==17496
    assert sum(EXPECT_ORBS[rec[0]] for rec in prev)==15259840
    prior_left=residual-prev
    assert len(prior_left)==241 and sum(EXPECT_ORBS[r[0]] for r in prior_left)==198080
    support_by_orbit={i:r for i,r in enumerate(ALL_22_SUPPORT_REPS)}
    # Standard 10-cycle rescue is inherited from published cycle theorem.
    cycles={i:has_c10(support_by_orbit[i]) for i in support_by_orbit}
    previous_cycles={r for r in prior_left if sorted(r[1:])==[1,1,1,1,59] and cycles[r[0]]}
    assert len(previous_cycles)==5 and sum(EXPECT_ORBS[r[0]] for r in previous_cycles)==3520
    actual={(c['orbit_1_based']-1,*c['stones']) for c in certs}
    expected=prior_left-previous_cycles
    assert actual==expected, ('missing',len(expected-actual),'unexpected',len(actual-expected))
    assert sum(EXPECT_ORBS[r[0]] for r in actual)==194560
    return len(residual),len(prev),len(previous_cycles),len(actual)

def cube_orbit_check(certs):
    rep={i:r for i,r in enumerate(ALL_22_SUPPORT_REPS)}
    for c in certs:
        k=c['orbit_1_based']-1
        assert tuple(c['vertices'])==rep[k]
    perms=list(itertools.permutations(range(5)))
    all_supports=set()
    for k,vertices in sorted(rep.items()):
        images=set()
        for perm in perms:
            shifted=[]
            for v in vertices:
                x=0
                for bit in range(5):
                    if (v>>bit)&1:x|=1<<perm[bit]
                shifted.append(x)
            for flip in range(32):images.add(tuple(sorted(x^flip for x in shifted)))
        assert len(images)==EXPECT_ORBS[k], (k,len(images),EXPECT_ORBS[k])
        assert not (images & all_supports), ('orbit collision',k)
        all_supports.update(images)
    assert len(all_supports)==24064
    return len(all_supports)

def main():
    reps=list(csv.DictReader((DATA/'remaining_236_representatives.csv').open(newline='',encoding='utf-8')))
    certs=[json.loads(s) for s in (DATA/'move_certificates_236.jsonl').read_text(encoding='utf-8').splitlines() if s.strip()]
    assert len(reps)==len(certs)==236
    by_method=Counter();weighted=Counter();moves_by_method=Counter();outcomes=Counter()
    for i,(r,c) in enumerate(zip(reps,certs)):
        assert c['representative_index0']==i
        assert c['orbit_1_based']==int(r['orbit_1_based'])
        assert c['vertices']==list(map(int,r['vertices_0_31'].split()))
        assert c['stones']==list(map(int,r['stone_counts'].split()))
        assert c['orbit_weight']==int(r['orbit_weight'])==EXPECT_ORBS[c['orbit_1_based']-1]
        outcome,amount=verify_move_record(c)
        outcomes[outcome]+=1
        by_method[c['method']]+=1
        weighted[c['method']]+=c['orbit_weight']
        moves_by_method[c['method']]+=len(c['moves'])
    assert dict(by_method)=={'supply_and_fold':214,'rooted_tree':4,'staged_integer_program':18}
    assert dict(weighted)=={'supply_and_fold':183200,'rooted_tree':1280,'staged_integer_program':10080}
    assert sum(moves_by_method.values())==6963
    assert sum(weighted.values())==194560
    assert cube_orbit_check(certs)==24064
    residual,parentcert,cycle,final=complete_against_v14(certs)
    assert math.comb(32,5)*math.comb(62,4)==112336594720
    assert 112336400160+sum(weighted.values())==112336594720
    print('CERTIFICATE REPLAY: PASS (all 236 representative configurations)')
    print('Source support-orbit symmetry verification: PASS (22 distinct orbits, 24,064 supports)')
    print('v1.4 residual matching: PASS (17,737 => 17,496 + 5 + 236 representatives)')
    print('Methods count:',dict(by_method))
    print('Weighted configuration count:',dict(weighted))
    print('Legal pebbling moves checked:',sum(moves_by_method.values()))
    print('End states:',dict(outcomes))
    print('Newly processed Q5 five-support configurations:',sum(weighted.values()))
    print('TOTAL conditional coverage of 63-stone exactly-five-support configurations:',112336594720)
    print('UNCHECKED HERE: inherited Q4 theorem, inherited one-versus-four case, v1.4 first-two-step exhaustive argument')
    print('NEW full-dimensional Q5 theorem: NOT CLAIMED')
    print('SHA256 move certificate file:',sha256(DATA/'move_certificates_236.jsonl'))
if __name__=='__main__':main()
