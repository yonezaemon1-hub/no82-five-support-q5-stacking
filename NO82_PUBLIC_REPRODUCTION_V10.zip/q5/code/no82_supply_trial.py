import csv,sys,collections,itertools,math
from pathlib import Path
rows=list(csv.DictReader((Path(__file__).resolve().parent.parent/'data/remaining_236_representatives.csv').open(newline='',encoding='utf-8')))
REPS=[list(map(int,r['vertices_0_31'].split())) for r in rows]
COUNTS=[list(map(int,r['stone_counts'].split())) for r in rows]

def flippath(r,t):
 d=r^t
 return [[r]+[v:=r ^ (sum(1<<bit for bit in perm[:i])) for i in range(1,len(perm)+1)] for perm in itertools.permutations([bit for bit in range(5) if (d>>bit)&1])]

def get_fold_req(a,axis,side):
 req={}
 for x,b in enumerate(a):
  if ((x>>axis)&1)==side and b%2:
   t=x^(1<<axis)
   if b==1:req[t]=max(req.get(t,0),2)
   elif b==3:req[t]=max(req.get(t,0),1)
 return req

def try_case(verts,counts):
 a0=[0]*32
 for v,c in zip(verts,counts):a0[v]=c
 for axis in range(5):
  for srcbit in [0,1]:
   a=a0.copy();req=get_fold_req(a,axis,srcbit)
   # require none of src side have odd 1/3 unsupported unless supply
   sources=sorted([i for i in range(32) if (i>>axis)&1!=srcbit and a[i]>3],key=lambda x:-a[x])
   if not sources:continue
   for source in sources:
    for targets in [sorted(req,key=lambda x:((x^source).bit_count(),-req[x])),sorted(req,key=lambda x:(-(x^source).bit_count(),-req[x]))]:
     a=a0.copy();path=[];good=True
     for t in targets:
      deficit=max(0,req[t]-a[t]);
      for i in range(deficit):
       paths=flippath(source,t)
       # minimize immediate cost (if intermediate stones exist)
       def cost(path):
        return sum(max(0,2**j-(a[v])) for j,v in enumerate(path))
       shortest=min(paths,key=cost)
       # recursively send 1 from source, using intermediate piles to move
       for v,w in zip(shortest,shortest[1:]):
        pass
       # generate 1 at target via recursive 'make(x,2)' on predecessor chain
       def get_to(x,amount,seen):
        if a[x]>=amount:return True
        if x==source:return False
        # only from predecessor on selected path
        j=shortest.index(x)
        pred=shortest[j-1]
        while a[x]<amount:
         if not get_to(pred,2,seen):return False
         a[pred]-=2;a[x]+=1;path.append((pred,x))
        return True
       if not get_to(t,req[t],set()):good=False;break
      if not good:break
     if not good:continue
     # fold
     for x in range(32):
      if ((x>>axis)&1)!=srcbit:continue
      y=x^(1<<axis);b=a[x]
      if b==0:continue
      if b%2==0:seq=[(x,y)]*(b//2)
      elif b>=5:seq=[(x,y)]*(b//2)+[(y,x),(x,y)]
      elif b==3 and a[y]>=1:seq=[(x,y),(y,x),(x,y)]
      elif b==1 and a[y]>=2:seq=[(y,x),(x,y)]
      else:good=False;break
      for u,v in seq:
       if a[u]<2:good=False;break
       a[u]-=2;a[v]+=1;path.append((u,v))
      if not good:break
     if good and sum(a)>=31 and all(a[x]==0 for x in range(32) if ((x>>axis)&1)==srcbit):return path,(axis,srcbit,source),a
 return None

if __name__=='__main__':
 good=[]
 for i,(v,c) in enumerate(zip(REPS,COUNTS)):
  out=try_case(v,c)
  if out:good.append(i)
 print('good',len(good),'of',len(REPS),good[:30])
