import csv,random,sys,time
sys.path.append('/mnt/data')
from no82_supply_trial import REPS,COUNTS

def sweep(verts,counts,root,parent):
 a=[0]*32
 for x,c in zip(verts,counts):a[x]=c
 path=[]
 def give(v,n):
  if a[v]>=n:return True
  if v==root:return False
  u=parent[v]
  while a[v]<n:
   if not give(u,2):return False
   a[u]-=2;a[v]+=1;path.append((u,v))
  return True
 for v in sorted(range(32),key=lambda v:(v^root).bit_count(),reverse=True):
  if v==root:continue
  while a[v]>=2:
   u=parent[v];a[v]-=2;a[u]+=1;path.append((v,u))
  if a[v]==1:
   if not give(v,2):return None
   u=parent[v];a[v]-=2;a[u]+=1;path.append((v,u))
 assert a[root]>0 and all(a[v]==0 for v in range(32) if v!=root)
 return path,a

def try_case(verts,counts,seed=47,trials=300):
 rr=random.Random(seed)
 roots=verts[:] +[r for r in range(32) if r not in verts]
 roots.sort(key=lambda x:-(sum(c * (0.5 ** ((x^v).bit_count())) for v,c in zip(verts,counts))))
 for root in roots:
  for trial in range(trials):
   par={};
   for v in range(32):
    if v==root:continue
    opts=[v^(1<<i) for i in range(5) if (v^root)&(1<<i)]
    par[v]=rr.choice(opts)
   z=sweep(verts,counts,root,par)
   if z:return z,root,trial
 return None

if __name__=='__main__':
 todo=[5,116,120,127,132,173,177,178,179,180,181,182,217,218,219,220,221,222,223,224,227,231]
 for i in todo:
  t=time.time();z=try_case(REPS[i],COUNTS[i],seed=i,trials=300)
  print(i,'YES' if z else 'NO',('root %s trials %s steps %s'%(z[1],z[2],len(z[0][0]))) if z else '',round(time.time()-t,2),flush=True)
