#!/usr/bin/env python3
"""Independent *move-by-move* verifier for v1.4 positive certificates.
No external dependencies. Never interprets absence of a certificate as a counterexample.
The Q4 31-stone theorem and the one-versus-four-support lemma are PREVIOUS,
UNINDEPENDENTLY AUDITED premises, not proven in this program.
"""
from pathlib import Path
import csv, hashlib

HERE=Path(__file__).resolve().parent.parent
REPS=[
(0,1,6,26,29),(0,1,6,26,31),(0,1,6,27,30),(0,1,6,27,31),
(0,1,14,22,27),(0,3,12,21,27),(0,3,12,21,31),
(0,1,6,25,30),(0,1,6,27,29),(0,1,14,22,31),
(0,3,5,24,30),(0,3,5,24,31),(0,3,5,26,28),(0,3,12,21,26),
(0,3,13,21,26),(0,1,2,29,31),(0,1,6,24,31),(0,1,6,30,31),
(0,3,12,23,29),(0,1,2,28,31),(0,1,2,29,30),(0,3,5,25,30)]
ORB=[1920]*7+[960]*8+[640,480,480,384,320,320,320]
assert len(REPS)==len(ORB)==22 and sum(ORB)==24064

def do_move(a,u,v):
    assert 0<=u<32 and 0<=v<32 and (u^v).bit_count()==1,(u,v)
    assert a[u]>=2,(u,v,a[u]);a[u]-=2;a[v]+=1


def fold_certificate(original):
    for axis in range(5):
        for srcbit in (0,1):
            a=original.copy();moves=0;okay=True
            for x in range(32):
                if (x>>axis)&1 != srcbit or a[x]==0:continue
                y=x^(1<<axis);b=a[x]
                if b%2==0: seq=[(x,y)]*(b//2)
                elif b>=5: seq=[(x,y)]*(b//2)+[(y,x),(x,y)]
                elif b==3 and a[y]>=1: seq=[(x,y),(y,x),(x,y)]
                elif b==1 and a[y]>=2: seq=[(y,x),(x,y)]
                else:okay=False;break
                for u,v in seq:do_move(a,u,v);moves+=1
            if okay and all(a[x]==0 for x in range(32) if (x>>axis)&1==srcbit) and sum(a)>=31:
                return axis,srcbit,moves,sum(a)
    return None


def cycle_10_support(S):
    start=S[0];need=set(S);path=[start];seen={start}
    def dfs(v):
        if len(path)==10:return (v^start).bit_count()==1 and need<=seen
        if 10-len(path)<len(need-seen):return False
        for k in range(5):
            w=v^(1<<k)
            if w in seen:continue
            path.append(w);seen.add(w)
            if dfs(w):return True
            seen.remove(w);path.pop()
        return False
    if dfs(start):
        assert len(set(path))==10
        assert all((path[i]^path[(i+1)%10]).bit_count()==1 for i in range(10))
        return path[:]
    return None


def main():
    data=(HERE/'data/prior_v14_residual_2.bin').read_bytes();assert len(data)%6==0
    residual={tuple(data[i:i+6]) for i in range(0,len(data),6)}
    assert len(residual)==17737
    assert sum(ORB[r[0]] for r in residual)==15457920

    seen=set();verified_weight=0;certificate_prep=0;certificate_fold=0;smallest=999;maxsize=0
    length_counts={}
    with (HERE/'data/prior_v14_all_certificates.csv').open(newline='') as f:
        reader=csv.reader(f)
        head=next(reader)
        assert head[0]=='orbit_index0'
        for fields in reader:
            r=tuple(int(x) for x in fields[:6]);s,*counts=r
            assert r in residual and r not in seen,r
            seen.add(r)
            n=int(fields[6]);path=[tuple(int(v) for v in part.split('-')) for part in fields[7:]]
            assert len(path)==n
            ar=[0]*32
            for x,c in zip(REPS[s],counts):ar[x]=c
            assert sum(ar)==63
            for u,v in path:do_move(ar,u,v)
            assert sum(ar)==63-n
            fold=fold_certificate(ar)
            assert fold is not None,r
            axis,side,moves,final_sum=fold
            assert final_sum>=31
            smallest=min(smallest,final_sum);maxsize=max(maxsize,final_sum)
            certificate_prep+=n;certificate_fold+=moves
            verified_weight+=ORB[s]
            length_counts[n]=length_counts.get(n,0)+ORB[s]

    leftover=residual-seen
    leftover_weight=sum(ORB[r[0]] for r in leftover)
    assert len(seen)==17496 and verified_weight==15259840
    assert len(leftover)==241 and leftover_weight==198080

    cycles={s:cycle_10_support(REPS[s]) for s in range(22)}
    cycle_rescue={r for r in leftover if sorted(r[1:])==[1,1,1,1,59] and cycles[r[0]] is not None}
    assert len(cycle_rescue)==5 and sum(ORB[r[0]] for r in cycle_rescue)==3520
    still_unresolved=leftover-cycle_rescue
    still_weight=sum(ORB[r[0]] for r in still_unresolved)
    assert len(still_unresolved)==236 and still_weight==194560
    # 22 challenging support orbits only; the one-versus-four premise is inherited (not re-proven).
    balanced_total=13423982080
    first_two_step=13408524160
    certified_balanced=first_two_step+verified_weight+3520
    assert certified_balanced+still_weight==balanced_total
    all_five_total=112336594720
    inherited_easy=98912612640
    assert inherited_easy+balanced_total==all_five_total
    total_conditional=inherited_easy+certified_balanced
    assert total_conditional+still_weight==all_five_total
    print('INDEPENDENT CERTIFICATE REPLAY: PASS')
    print('representatives in residual after 0-2 prep:',len(residual),'weighted=',15457920)
    print('new explicit move certificates:',len(seen),'weighted=',verified_weight)
    print('prep pebbling moves replayed:',certificate_prep)
    print('folding pebbling moves replayed:',certificate_fold)
    print('TOTAL LEGAL MOVES REPLAYED:',certificate_prep+certificate_fold)
    print('remaining pebbles after folding: min=',smallest,'max=',maxsize)
    print('move length histogram weighted:',dict(sorted(length_counts.items())))
    print('additional C10 almost-stacked prior-theorem applications:',len(cycle_rescue),'weighted=',3520)
    print('remaining unproven representatives:',len(still_unresolved),'weighted=',still_weight)
    print('22-orbit BALANCED SUPPORT conditional covered=',certified_balanced,'/',balanced_total)
    print('ALL FIVE-SUPPORT conditional covered=',total_conditional,'/',all_five_total)
    print('NORM: conditional on previous Q4 stacking theorem + earlier singleton-separation lemma')
    print('NO CLAIM: Q5 full threshold, Q_n full formula, all 236 unresolved as failures')
    print('SHA256(all_certificates.csv)=',hashlib.sha256((HERE/'data/prior_v14_all_certificates.csv').read_bytes()).hexdigest())

if __name__=='__main__':main()
