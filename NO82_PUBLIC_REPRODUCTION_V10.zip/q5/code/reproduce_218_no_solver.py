#!/usr/bin/env python3
"""Regenerate the 214 supply/fold and 4 rooted-tree certificates with Python stdlib.
The remaining 18 were found with an optional MILP solver; their fixed legal
move sequences are verified by verify_v15_independent.py without that solver.
"""
from pathlib import Path
import json
from no82_supply_trial import REPS, COUNTS, try_case as supply
from no82_tree_sweep import try_case as tree
BASE=Path(__file__).resolve().parent.parent
records=[json.loads(line) for line in (BASE/'data/move_certificates_236.jsonl').read_text(encoding='utf-8').splitlines() if line.strip()]
a=b=0
for rec in records:
 i=rec['representative_index0']
 expected=[tuple(z) for z in rec['moves']]
 if rec['method']=='supply_and_fold':
  found=supply(REPS[i],COUNTS[i])
  assert found is not None and found[0]==expected, i
  a+=1
 elif rec['method']=='rooted_tree':
  found=tree(REPS[i],COUNTS[i],seed=i,trials=300)
  assert found is not None and found[0][0]==expected, i
  b+=1
assert (a,b)==(214,4)
print(f'REGENERATION PASS: {a} supply/fold and {b} rooted-tree paths (218 total)')
