#include <cstdint>
#include <iostream>
using namespace std;
static const int reps[22][5] = {
{0,1,6,26,29},{0,1,6,26,31},{0,1,6,27,30},{0,1,6,27,31},
{0,1,14,22,27},{0,3,12,21,27},{0,3,12,21,31},
{0,1,6,25,30},{0,1,6,27,29},{0,1,14,22,31},
{0,3,5,24,30},{0,3,5,24,31},{0,3,5,26,28},{0,3,12,21,26},
{0,3,13,21,26},{0,1,2,29,31},{0,1,6,24,31},{0,1,6,30,31},
{0,3,12,23,29},{0,1,2,28,31},{0,1,2,29,30},{0,3,5,25,30}
};
static const int orbit[22]={1920,1920,1920,1920,1920,1920,1920,960,960,960,960,960,960,960,960,640,480,480,384,320,320,320};
// Does some entire halfcube absorb into the other in ≤available pebbling moves, with target ≥31?
static inline bool good_fold(const int* arr,const int *xs,int count, int T){
  for(int bit=0;bit<5;bit++){
   for(int side=0;side<2;side++){
    int R=0,o=0;bool valid=true;
    for(int i=0;i<count;i++){
     int x=xs[i],c=arr[x];
     if(((x>>bit)&1)!=side) {R+=c;continue;}
     if((c&1)) {o++;int opposite=arr[x^(1<<bit)];if((c==1 && opposite<2)||(c==3 && opposite<1)){valid=false;break;}}
    }
    if(valid && T+R-3*o >= 62)return true;
   }
  }
  return false;
}
static bool two_move(int* arr,const int* origin) {
  int xs[7];for(int k=0;k<5;k++)xs[k]=origin[k];
  for(int i=0;i<5;i++){
    int x=origin[i];if(arr[x]<2)continue;
    for(int bit=0;bit<5;bit++){
      int y=x^(1<<bit);
      arr[x]-=2;arr[y]++;
      int k=5;
      bool exists=false;for(int j=0;j<5;j++)if(xs[j]==y)exists=true;
      if(!exists)xs[k++]=y;
      for(int j=0;j<k;j++){
        int x2=xs[j]; if(arr[x2]<2)continue;
        for(int bit2=0;bit2<5;bit2++){
           int y2=x2^(1<<bit2);
           arr[x2]-=2;arr[y2]++;
           int z=k;bool has=false;
           for(int l=0;l<k;l++) if(xs[l]==y2)has=true;
           if(!has)xs[z++]=y2;
           bool hit=good_fold(arr,xs,z,61);
           arr[y2]--;arr[x2]+=2;
           if(hit){arr[y]--;arr[x]+=2;return true;}
        }
      }
      arr[y]--;arr[x]+=2;
    }
  }
  return false;
}
int main(){
 uint64_t tot=0, base=0, single=0, double_move=0, rest=0;
 for(int s=0;s<22;s++){
  uint64_t bcount=0, ocount=0, twocount=0, rem=0;
  int arr[32]={0};int xs[6];
  for(int j=0;j<5;j++)xs[j]=reps[s][j];
  for(int a=1;a<60;a++)for(int b=1;b<61-a;b++)for(int c=1;c<62-a-b;c++)for(int d=1;d<63-a-b-c;d++){
   int e=63-a-b-c-d; if(e<=0)continue;
   arr[xs[0]]=a;arr[xs[1]]=b;arr[xs[2]]=c;arr[xs[3]]=d;arr[xs[4]]=e;
   if(good_fold(arr,xs,5,63)){bcount++;goto clear;}
   for(int j=0;j<5;j++) if(arr[xs[j]]>=2){
    int x=xs[j];
    for(int bit=0;bit<5;bit++){
     int y=x^(1<<bit);
     arr[x]-=2; arr[y]+=1;
     bool existed=false;
     for(int z=0;z<5;z++)if(xs[z]==y){existed=true;break;}
     if(!existed)xs[5]=y;
     bool found=good_fold(arr,xs,existed?5:6,62);
     arr[y]-=1;arr[x]+=2;
     if(found){ocount++;goto clear;}
    }
   }
   if(two_move(arr,xs)){twocount++;goto clear;}
   rem++;
   clear:
    for(int j=0;j<5;j++)arr[xs[j]]=0;
  }
  if(bcount+ocount+twocount+rem!=557845){cerr<<"bad count"<<s<<" "<<bcount<<" "<<ocount<<" "<<twocount<<" "<<rem<<"\n";return 1;}
  cout<<"rep="<<s+1<<" base="<<bcount<<" one_move_extra="<<ocount<<" two_move_extra="<<twocount<<" unresolved="<<rem<<"\n";
  tot+=557845ULL*orbit[s];base+=bcount*orbit[s];single+=ocount*orbit[s];double_move+=twocount*orbit[s];rest+=rem*orbit[s];
 }
 cout<<"WEIGHTED total="<<tot<<" base="<<base<<" one_move_extra="<<single<<" two_move_extra="<<double_move<<" unresolved="<<rest<<" proven="<<base+single+double_move<<" fraction="<<100.0*(base+single+double_move)/tot<<"\n";
}
