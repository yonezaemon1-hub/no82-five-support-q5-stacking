import numpy as np,time,sys
from scipy.optimize import milp, Bounds, LinearConstraint
from scipy.sparse import lil_matrix, vstack, csr_matrix
from pathlib import Path
import csv
edges=[(u,u^(1<<k)) for u in range(32) for k in range(5)]
rows=list(csv.DictReader((Path(__file__).resolve().parent.parent/'data/remaining_236_representatives.csv').open(newline='',encoding='utf-8')))

E=len(edges)
A=np.zeros((32,E),np.int8);O=np.zeros((32,E),np.int8)
for i,(u,v) in enumerate(edges):A[u,i]-=2;A[v,i]+=1;O[u,i]=2


def phase_solver(cs,root,T=12,lim=10):
 c=np.zeros(32)
 for v,n in cs:c[v]=n
 mat=lil_matrix((T*32+31,T*E),dtype=float)
 low=np.empty(T*32+31);up=np.empty_like(low)
 ix=0
 for t in range(T):
  # initial before stage t = c+ sum previous A*x
  # 2*out in phase t - previous(A*x) <= c
  for v in range(32):
   for k in range(t):
    for e in np.flatnonzero(A[v,:]):mat[ix,k*E+e]=-A[v,e]
   for e in np.flatnonzero(O[v,:]):mat[ix,t*E+e]=O[v,e]
   low[ix]=-np.inf;up[ix]=c[v];ix+=1
 # terminal for all nonroot vertex require c+ΣA*x=0
 for v in range(32):
  if v==root:continue
  for k in range(T):
   for e in np.flatnonzero(A[v,:]):mat[ix,k*E+e]=A[v,e]
  low[ix]=-c[v];up[ix]=-c[v];ix+=1
 assert ix==len(low)
 obj=np.tile(np.ones(E),T)+np.repeat(np.arange(T)*0.0001,E)
 result=milp(c=obj,integrality=np.ones(T*E),bounds=Bounds(np.zeros(T*E),np.full(T*E,63.0)),constraints=LinearConstraint(mat.tocsr(),low,up),options={'time_limit':lim,'mip_rel_gap':0.01,'presolve':True})
 if result.x is None:return result.status,None,result.message
 x=np.rint(result.x.reshape(T,E)).astype(int); return result.status,x,result.fun

def verify(cs,root,x):
 a=np.zeros(32,dtype=int)
 for v,n in cs:a[v]=n
 moves=[]
 for row in x:
  aa=a.copy()
  for i,num in enumerate(row):
   if not num:continue
   u,v=edges[i];assert num>0 and aa[u]>=2*num
   aa[u]-=2*num
  for i,num in enumerate(row):
   if not num:continue
   u,v=edges[i]
   for _ in range(num):a[u]-=2;a[v]+=1;moves.append((u,v))
 assert all(a[v]==0 for v in range(32) if v!=root)
 return moves,a
if __name__=='__main__':
 for idx in [5,116,177,217]:
  r=rows[idx];cs=list(zip(map(int,r['vertices_0_31'].split()),map(int,r['stone_counts'].split())))
  print('CASE',idx,cs,flush=True)
  for rt in [cs[-1][0],31,0]:
   t=time.time();st,x,fn=phase_solver(cs,rt,T=10,lim=8)
   print('root',rt,'status',st,'fun',fn,'time',round(time.time()-t,2),flush=True)
   if x is not None:
    m,a=verify(cs,rt,x);print('CERT',len(m),[(i,n) for i,n in enumerate(a) if n],flush=True);break
