// Separate C++17 verifier for all No.82 v1.5 explicit move certificates.
// Checks legal moves and target structure. It does not assume the search
// methods, nor prove inherited Q4 theorem or novelty.
#include <array>
#include <bitset>
#include <cassert>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
using namespace std;
vector<string> split(const string &s,char d) { vector<string> out; string p; istringstream in(s); while(getline(in,p,d))out.push_back(p);return out; }
vector<int> read_ints(const string &s){vector<int> v;istringstream in(s);int x;while(in>>x)v.push_back(x);return v;}
int ones(int n){int o=0;while(n){o+=n&1;n>>=1;}return o;}
int main(int argc,char** argv){
 if(argc!=2){cerr<<"USAGE verify_v15_cpp <move_certificates_compact.csv>\n";return 2;}
 try {
  ifstream f(argv[1]);if(!f)throw runtime_error("cannot read certificate CSV");
  string line;getline(f,line);int n=0,sumWeight=0,sumMoves=0,fd=0,direct=0;
  int nSupply=0,nTree=0,nMilp=0,wSupply=0,wTree=0,wMilp=0;
  while(getline(f,line)){
   if(line.empty())continue;
   auto z=split(line,',');if(z.size()!=10)throw runtime_error("invalid CSV field count");
   int index=stoi(z[0]),orbit=stoi(z[1]),weight=stoi(z[4]),axis=stoi(z[6]),side=stoi(z[7]),root=stoi(z[8]);
   if(index!=n || orbit<1 || orbit>22 || weight<1)throw runtime_error("index/orbit invalid");
   auto vs=read_ints(z[2]),cs=read_ints(z[3]);
   if(vs.size()!=5 || cs.size()!=5)throw runtime_error("need five vertices and stone counts");
   array<int,32> a{};int N=0;
   for(int j=0;j<5;j++){
     int v=vs[j],s=cs[j]; if(v<0||v>=32||s<1||a[v]!=0)throw runtime_error("bad initial support");
     a[v]=s;N+=s;
   }
   if(N!=63)throw runtime_error("initial stone count wrong");
   int moves=0;istringstream in(z[9]);string move;
   while(in>>move){
    auto dash=move.find('-');if(dash==string::npos)throw runtime_error("bad move token");
    int u=stoi(move.substr(0,dash)),v=stoi(move.substr(dash+1));
    if(u<0||u>=32||v<0||v>=32||ones(u^v)!=1||a[u]<2)throw runtime_error("illegal pebbling move in certificate "+to_string(n));
    a[u]-=2;a[v]++;moves++;
   }
   N=0;int supp=0;for(int p:a){N+=p;supp+=(p>0);}
   if(N!=63-moves||N<1)throw runtime_error("wrong pebble conservation");
   string method=z[5];
   if(method=="supply_and_fold"){
    if(axis<0||axis>=5||(side!=0&&side!=1)||N<31)throw runtime_error("invalid fold metadata or insufficient remaining stones");
    for(int v=0;v<32;v++)if(((v>>axis)&1)==side && a[v]!=0)throw runtime_error("incomplete Q4 face transfer");
    nSupply++;wSupply+=weight;fd++;
   }else if(method=="rooted_tree"||method=="staged_integer_program"){
    if(root<0||root>=32 || supp!=1 || a[root]!=N)throw runtime_error("not stacked at claimed root");
    if(method=="rooted_tree"){nTree++;wTree+=weight;}else{nMilp++;wMilp+=weight;}
    direct++;
   }else throw runtime_error("invalid method");
   n++;sumWeight+=weight;sumMoves+=moves;
  }
  if(n!=236||sumWeight!=194560||sumMoves!=6963||fd!=214||direct!=22||nSupply!=214||nTree!=4||nMilp!=18||wSupply!=183200||wTree!=1280||wMilp!=10080)throw runtime_error("summary totals disagree");
  cout<<"INDEPENDENT C++ MOVE CERTIFICATE REPLAY: PASS\n";
  cout<<"representatives="<<n<<" legal_moves="<<sumMoves<<" orbit_weighted_configs="<<sumWeight<<"\n";
  cout<<"Q4 conditional face reduction="<<fd<<" Q5 direct stacking="<<direct<<"\n";
  cout<<"This program checks the v1.5 certificates only; inherited Q4 theorem is not re-proven.\n";
 } catch(exception& e){cerr<<"FAIL: "<<e.what()<<"\n";return 1;}
}
