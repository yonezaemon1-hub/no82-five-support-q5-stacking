$ErrorActionPreference='Stop'
Set-Location $PSScriptRoot
Write-Host 'NO82 v1.5 Windows audit START (PUBLIC RELEASE v1.0)'
foreach($line in Get-Content '.\SHA256SUMS.txt' -Encoding UTF8){
 if($line -match '^([a-fA-F0-9]{64})  (.+)$'){
  $expected=$Matches[1].ToLowerInvariant(); $rel=$Matches[2]
  $full=Join-Path $PSScriptRoot $rel
  if(-not (Test-Path -LiteralPath $full)){throw "Missing file: $rel"}
  $h=(Get-FileHash -LiteralPath $full -Algorithm SHA256).Hash.ToLowerInvariant()
  if($h -ne $expected){throw "SHA256 mismatch: $rel"}
  Write-Host "SHA256 PASS $rel"
 }elseif($line.Trim().Length -gt 0){throw "Invalid SHA line: $line"}
}
$py=Get-Command python -ErrorAction SilentlyContinue
if(-not $py){throw 'Python 3 is required'}
& python '.\code\verify_v15_independent.py'
if($LASTEXITCODE -ne 0){throw 'v1.5 Python replay FAILED'}
& python '.\code\verify_prior_v14_replay.py'
if($LASTEXITCODE -ne 0){throw 'Prior v1.4 Python replay FAILED'}
& python '.\code\reproduce_218_no_solver.py'
if($LASTEXITCODE -ne 0){throw '218 source regeneration FAILED'}
$cpp=Get-Command g++ -ErrorAction SilentlyContinue
if(-not $cpp){throw 'g++ is required for independent C++ checks'}
$e1=Join-Path $env:TEMP 'no82_v15_cert_replay.exe'
& g++ -O2 -std=c++17 '.\code\verify_v15_cpp.cpp' -o $e1
if($LASTEXITCODE -ne 0){throw 'C++ certificate checker compile FAILED'}
& $e1 '.\data\move_certificates_compact.csv'
if($LASTEXITCODE -ne 0){throw 'C++ certificate replay FAILED'}
$e2=Join-Path $env:TEMP 'no82_v14_two_step_recount.exe'
& g++ -O2 -std=c++17 '.\code\verify_prior_two_step.cpp' -o $e2
if($LASTEXITCODE -ne 0){throw 'Prior C++ recount compile FAILED'}
$result=& $e2
if($LASTEXITCODE -ne 0){throw 'Prior v1.4 C++ count FAILED'}
$last=$result | Select-Object -Last 1
Write-Host $last
if($last -notmatch 'unresolved=15457920'){throw 'Prior v1.4 remainder count mismatch'}
Write-Host 'NO82 v1.5 Windows audit LOCAL REPRODUCTION PASS'
Write-Host 'Independent AI mathematical audit reported PASS; novelty remains INCONCLUSIVE.'
