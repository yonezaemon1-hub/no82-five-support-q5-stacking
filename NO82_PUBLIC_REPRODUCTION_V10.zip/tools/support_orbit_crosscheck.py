#!/usr/bin/env python3
"""Independent classification of *all* 201,376 five-vertex Q5 supports.
Does not import any of the frozen Q5 verifier sources.
"""
import itertools, math, collections
classes = collections.Counter()
balanced = set()
for support in itertools.combinations(range(32), 5):
    counts = [sum((v >> bit)&1 for v in support) for bit in range(5)]
    if any(x in (0,5) for x in counts): classes['constant'] += 1
    elif any(x in (1,4) for x in counts): classes['singleton_only'] += 1
    else: classes['balanced'] += 1;balanced.add(support)
assert sum(classes.values())==math.comb(32,5)==201376
assert classes['balanced']==24064
assert classes['constant']+classes['singleton_only']==177312
# 22 canonical support seeds from an independent data read of the frozen research definition.
seeds = (
 (0,1,6,26,29),(0,1,6,26,31),(0,1,6,27,30),(0,1,6,27,31),
 (0,1,14,22,27),(0,3,12,21,27),(0,3,12,21,31),
 (0,1,6,25,30),(0,1,6,27,29),(0,1,14,22,31),
 (0,3,5,24,30),(0,3,5,24,31),(0,3,5,26,28),(0,3,12,21,26),
 (0,3,13,21,26),(0,1,2,29,31),(0,1,6,24,31),(0,1,6,30,31),
 (0,3,12,23,29),(0,1,2,28,31),(0,1,2,29,30),(0,3,5,25,30)
)
all_images = set()
sizes = []
for ss in seeds:
    images=set()
    for p in itertools.permutations(range(5)):
        permuted=[sum(((v>>k)&1)<<p[k] for k in range(5)) for v in ss]
        for mask in range(32): images.add(tuple(sorted(x^mask for x in permuted)))
    assert not images.intersection(all_images), 'overlapping orbits'
    all_images.update(images)
    sizes.append(len(images))
assert all_images == balanced
assert collections.Counter(sizes)==collections.Counter([1920]*7+[960]*8+[640,480,480,384,320,320,320])
assert 24064*math.comb(62,4)==13423982080
assert 177312*math.comb(62,4)==98912612640
assert 13408524160+15259840+3520+194560==13423982080
print('SUPPORT AND ORBIT CLASSIFICATION PASS')
print('ALL SUPPORTS:',sum(classes.values()))
print('CONSTANT:',classes['constant'],'SINGLETON_ONLY:',classes['singleton_only'],'BALANCED:',classes['balanced'])
print('ORBITS:',len(sizes),'SIZES:',sizes)
print('BALANCED CONFIGURATIONS:',13423982080)
print('EASY CONFIGURATIONS:',98912612640)
print('TOTAL CONFIGURATIONS:',112336594720)
