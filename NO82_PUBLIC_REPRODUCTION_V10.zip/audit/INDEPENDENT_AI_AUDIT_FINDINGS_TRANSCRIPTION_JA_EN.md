# No.82 independent AI audit — transcribed findings supplied by author

Date: 2026-11-23 (JST). Source: user pasted the auditor's report in conversation. This is not the auditor's original Markdown report file. The attached reimplementation ZIP is the actual received code-and-logs archive.

## Reported gates

| Gate | Finding |
|---|---|
| PACKAGE | PASS |
| WINDOWS PROVENANCE | INCONCLUSIVE |
| MODEL | PASS |
| ANALYTIC LEMMAS | PASS |
| Q4 COMPUTATIONAL COVERAGE | PASS |
| Q5 ORBIT & PARTITION | PASS |
| MOVE CERTIFICATES | PASS |
| CONDITIONAL THEOREM | PASS |
| NOVELTY | INCONCLUSIVE |
| REFERENCES | PARTIAL |

## Reported independently checked facts

- Q5 support partition 41,440 / 135,872 / 24,064 and 22 orbits with matching orbit sizes.
- Independent 0–2-step weighted fold counts: base 13,318,106,240; 1-step 65,024,480; 2-step 25,393,440; unresolved 15,457,920. Exact row set of 17,737 residual allocations matched.
- v1.4 17,496 move certificates and v1.5 236 (6,963 moves) were replayed independently. For v1.5: 214 Q4-face reductions and 22 direct Q5 stacks.
- Independent Q4 scan over 41,677,241 majority-centered allocations, path-cover patterns count 28,278; 18 residual cases and 489 moves matched; 128 Case-II certificates (3,664 moves) were independently replayed.
- Independent Q3 terminal-profile DP, 16 halfcube split pairs, zero unmergeable pairs.
- Five C10 special allocations were directly stacked by an independent DFS, 60–61 legal operations each, so the independent audit did not rely on the cited cycle theorem for those instances.
- Singleton-separation b=1,3 proof was manually checked and counterexample searched.
- Auditor stated original author code was not executed during its independent reimplementation.

## Reservations

- The original Windows log was not in the auditor's custody; the original Windows provenance remains INCONCLUSIVE. Author-side Windows console transcript separately reports PASS.
- References partially checked, not fully line-by-line. A reported 9-vertex counterexample attributed to Fairfax-Ball was not verified.
- No comprehensive novelty search or formal verification or human peer review.
- No proof of stack(Q5)=63 over all support sizes or of stack(Q_n)=2^{n+1}-1 for all n.
- Existing LaTeX/Section 6 contained stale Windows pending text, corrected only in new publication-candidate editorial source.

The auditor reported no FAIL findings within its stated scope. The archived author-source ZIPs remain unchanged.
