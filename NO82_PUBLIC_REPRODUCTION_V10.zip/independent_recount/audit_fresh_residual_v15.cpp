// Independent exhaustive audit of Q5 five-point balanced-support residuals.
// Audit-only: not part of the mathematical publication and does not assume Q4.
// Each resulting six-byte record: support-orbit index (0..21), positive counts.
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
using namespace std;
static constexpr int reps[22][5] = {
{0,1,6,26,29},{0,1,6,26,31},{0,1,6,27,30},{0,1,6,27,31},
{0,1,14,22,27},{0,3,12,21,27},{0,3,12,21,31},
{0,1,6,25,30},{0,1,6,27,29},{0,1,14,22,31},
{0,3,5,24,30},{0,3,5,24,31},{0,3,5,26,28},{0,3,12,21,26},
{0,3,13,21,26},{0,1,2,29,31},{0,1,6,24,31},{0,1,6,30,31},
{0,3,12,23,29},{0,1,2,28,31},{0,1,2,29,30},{0,3,5,25,30}
};
using Board=array<int,32>;

// Fully clear one side via its paired edges; compute *actual* final stone total.
// Even piles contribute b/2; 5+ odd contributes (b-3)/2;
// odd three consumes a matching target pebble (net contribution zero);
// a singleton needs two matching pebbles and consumes one of them.
static bool can_clear(const Board &a) {
    for(int axis=0;axis<5;axis++) for(int side=0;side<2;side++) {
        int remaining=0;
        bool possible=true;
        for(int u=0;u<32;u++) if(((u>>axis)&1)!=side) {
            int target=a[u], source=a[u^(1<<axis)];
            if((source&1)==0)remaining+=target+source/2;
            else if(source>=5)remaining+=target+(source-3)/2;
            else if(source==3 && target>=1)remaining+=target;
            else if(source==1 && target>=2)remaining+=target-1;
            else {possible=false;break;}
        }
        if(possible && remaining>=31)return true;
    }
    return false;
}

static bool handled(Board &a, int depth) {
    if(can_clear(a))return true;
    if(depth==0)return false;
    for(int u=0;u<32;u++) if(a[u]>=2) {
       for(int bit=0;bit<5;bit++) {
          int v=u^(1<<bit);
          a[u]-=2; a[v]++;
          bool found=handled(a,depth-1);
          a[v]--; a[u]+=2;
          if(found)return true;
       }
    }
    return false;
}

int main(int argc,char**argv) {
    if(argc!=2){cerr<<"Usage: audit_fresh_residual_v15 output.bin\n";return 2;}
    ofstream output(argv[1],ios::binary); if(!output)return 2;
    uint64_t total=0,left=0;
    for(int k=0;k<22;k++) {
        uint64_t thisLeft=0;
        Board board{};
        const int *p=reps[k];
        for(int a=1;a<=59;a++)for(int b=1;b<=60-a;b++)
        for(int c=1;c<=61-a-b;c++)for(int d=1;d<=62-a-b-c;d++) {
            int e=63-a-b-c-d;
            board[p[0]]=a;board[p[1]]=b;board[p[2]]=c;
            board[p[3]]=d;board[p[4]]=e;
            total++;
            if(!handled(board,2)) {
                const unsigned char rec[6]={(unsigned char)k,(unsigned char)a,
                 (unsigned char)b,(unsigned char)c,(unsigned char)d,(unsigned char)e};
                output.write(reinterpret_cast<const char*>(rec),6);
                left++; thisLeft++;
            }
            for(int j=0;j<5;j++)board[p[j]]=0;
        }
        cerr<<"orbit="<<k+1<<" not_resolved="<<thisLeft<<"\n";
    }
    output.close();
    cout<<"fresh total="<<total<<" residual="<<left<<"\n";
    return total==12272590ULL && left==17737ULL ? 0:1;
}
